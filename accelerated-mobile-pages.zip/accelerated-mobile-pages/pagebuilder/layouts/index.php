<?php
if ( ! defined( 'ABSPATH' ) ) // Or some other WordPress constant
     exit;
