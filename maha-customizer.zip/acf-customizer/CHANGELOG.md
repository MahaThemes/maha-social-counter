ACF Customizer
==============

0.2.7
-----
 - fix PHP fatal when acf is not active

0.2.3 - 0.2.5
-------------
...

0.2.2
-----
 - Fix: Post preview values
 - UI: use curly arrow left for Focus-Btn
 - JS Fix: Numeric Field identification


0.2.1
-----
 - Focus controls: improve frontend css

0.2.0
------
 - Feature: Focus controls (call `do_action('acf_customizer_(row|field|sub_field))')` in theme)
 - Fix: Theme mod Repeatable values not loaded
 - Fix: Repeater Layout not converted to block
 - Style: More Compact Controls

0.1.15
------
 - fix php warning

0.1.14
------
 - fix: Preview values were loaded from wrong customizer section

0.1.13
------
 - fix locked form after input changed

0.1.12
------
 - rm var_dump

0.1.11
------
 - Force block layout (repeater, flexible content, group)

0.1.6
-----
 - Introduce changelog
 - Supprt afragen/github-updater
