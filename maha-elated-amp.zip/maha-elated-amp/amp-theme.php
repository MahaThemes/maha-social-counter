<?php
/*
Plugin Name: Elated AMP Theme
Plugin URI: https://mahative.com
Description: Optimized AMP Theme for Elated Theme
Version: 1.0
Author: MahaThemes
Author URI: https://mahative.com
License: GPL2
AMP: Elated AMP Theme
*/

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) exit;