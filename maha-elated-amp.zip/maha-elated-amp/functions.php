<?php 
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

if ( ! defined('AMPFORWP_CUSTOM_THEME') ) {
	define('AMPFORWP_CUSTOM_THEME', AMPFORWP_MAIN_PLUGIN_DIR."/".$ampforwp_design_selector);
}

// Loading the Components
// Big Post Image
add_image_size( 'amp-featured-large', 723, 394, true ); 
// Small Post Image
add_image_size( 'amp-featured-small', 346, 188, true );
//Single post leftside Image
add_image_size( 'amp-single-img', 220, 134, true );
//Search
add_amp_theme_support('AMP-search');
//Logo
add_amp_theme_support('AMP-logo');
//Social Icons
add_amp_theme_support('AMP-social-icons');
//Menu
add_amp_theme_support('AMP-menu');
add_amp_theme_support('AMP-alter-menu');
//Call Now
// add_amp_theme_support('AMP-call-now');
//Breadcrumb
// add_amp_theme_support('AMP-breadcrumb');
// Featured Image
add_amp_theme_support('AMP-featured-image');
//Author box
add_amp_theme_support('AMP-author-box');
//Loop
add_amp_theme_support('AMP-loop');
// Categories and Tags list
add_amp_theme_support('AMP-categories-tags');
// Comments
add_amp_theme_support('AMP-comments');
//Post Navigation
add_amp_theme_support('AMP-post-navigation');
// Related Posts
add_amp_theme_support('AMP-related-posts');
// Post Pagination
add_amp_theme_support('AMP-post-pagination');
// Icons example
// add_amp_icon( array( 'widgets', 'search', 'shopping-cart' ) );

// custom related posts args
function elated_ampforwp_related_post_loop_query(){
	global $post,  $redux_builder_amp;
	$string_number_of_related_posts = $redux_builder_amp['ampforwp-number-of-related-posts'];
	$int_number_of_related_posts = (int)$string_number_of_related_posts;
	$args = null;
	$orderby = 'ID';
    if( true == ampforwp_get_setting('ampforwp-single-order-of-related-posts')){
			$orderby = 'rand';
		}
	$args=array(
	'post_type'	   => get_post_type($post),
    'post__not_in' => array($post->ID),
    'posts_per_page'=> $int_number_of_related_posts,
    'orderby' => $orderby,
    'ignore_sticky_posts'=>1,
	'has_password' => false ,
	'post_status'=> 'publish',
	'no_found_rows'	=> true
	);
	if($redux_builder_amp['ampforwp-single-select-type-of-related']==2 && 'post' == $post->post_type ){
	    $categories = get_the_category($post->ID);
		if ($categories) {
				$category_ids = array();
				foreach($categories as $individual_category){ $category_ids[] = $individual_category->term_id;
				}
				$args['category__in'] = $category_ids;
		}
	} 
    // tags
	if($redux_builder_amp['ampforwp-single-select-type-of-related']==1 && 'post' == $post->post_type ) {
		$ampforwp_tags = get_the_tags($post->ID);
		if ($ampforwp_tags) {
						$tag_ids = array();
						foreach($ampforwp_tags as $individual_tag) {
							$tag_ids[] = $individual_tag->term_id;
						}
						$args['tag__in'] = $tag_ids;

		}
	}
	// Related Posts Based on Past few Days #2132
	if ( isset($redux_builder_amp['ampforwp-related-posts-days-switch']) && true == $redux_builder_amp['ampforwp-related-posts-days-switch'] ) {
		$date_range = strtotime ( '-' . $redux_builder_amp['ampforwp-related-posts-days-text'] .' day' );
		$args['date_query'] = array(
					            array(
					                'after' => array(
					                    'year'  => date('Y', $date_range ),
					                    'month' => date('m', $date_range ),
					                    'day'   => date('d', $date_range ),
					                	),
					            	)
					       		); 
	}
	$args = apply_filters('ampforwp_component_related_post_args' , $args );
	$my_query = new wp_query( $args );

	return $my_query;
}

// Remove default sticky social from Swift
remove_action('amp_post_template_footer','ampforwp_sticky_social_icons');
remove_action('amp_post_template_css','amp_social_styles',11);
//Twitter title #2744
function ampforwp_sanitize_twitter_title($post_title){
	$post_title = html_entity_decode( $post_title, ENT_QUOTES, 'UTF-8' );
    $post_title = rawurlencode( $post_title );
    $post_title = esc_html( $post_title );
    return $post_title;
}

function elated_amp_menu($echo=true, $menu_args=array(), $type='header'){
	if ( ($type == 'header' && ! has_nav_menu( 'amp-menu' )) || ( 'footer' == $type && ! has_nav_menu( 'amp-footer-menu' ) ) ) {
		return false;
	}
	global $loadComponent;
	if(isset($loadComponent['AMP-menu']) && $loadComponent['AMP-menu']==true){
		
		if ( false != get_transient('ampforwp_header_menu') && 'header' == $type ){
			$amp_menu = get_transient('ampforwp_header_menu');
		}
		elseif (false != get_transient('ampforwp_footer_menu') && 'footer' == $type) {
			$amp_menu = get_transient('ampforwp_footer_menu');
		}
		else{
			$amp_menu = elated_amp_menu_html($echo, $menu_args, $type);
		}

		if ( false == $echo ) {
			return $amp_menu;
		}
		else
			echo $amp_menu; // escaped above
	}
}

function elated_amp_menu_html($echo, $menu_args, $type){
	$theme_location = 'amp-menu';
	if ( 'amp-alternative-menu' == $type ) {
		$theme_location = 'amp-alternative-menu';
	}
	if( has_nav_menu( 'amp-menu' ) || has_nav_menu( 'amp-footer-menu' ) || has_nav_menu( 'amp-alternative-menu' ) ) {
		if ( !empty($menu_args) && isset($menu_args['walker']) ) {
			$menu_args['walker'] = new Ampforwp_Walker_Nav_Menu();
		}
		if (empty($menu_args)){
			$menu_args = array(
	            'theme_location' => $theme_location,
	            'container'=>'aside',
	            'menu'=>'ul',
	            'menu_class'=>'amp-menu',
	            'echo' => false,
				'walker' => new Ampforwp_Walker_Nav_Menu()
	        );
		}
	    $menu_html_content = wp_nav_menu( $menu_args );
	    // $menu_html_content = apply_filters('ampforwp_menu_content', $menu_html_content);
	    $sanitizer_obj = new AMPFORWP_Content( $menu_html_content, array(), apply_filters( 'ampforwp_content_sanitizers', array( 'AMP_Img_Sanitizer' => array(), 'AMP_Style_Sanitizer' => array(), ) ) );
		$sanitized_menu =  $sanitizer_obj->get_amp_content();
		
	    $menu_cache = true;
	    if ( class_exists('Sitepress') ) {
			$menu_cache = false;
	    }
	    if(defined('QTX_VERSION')){ // FOR qTranslate-X 
			$menu_cache = false;
	    }
	    $menu_cache = apply_filters('ampforwp_menu_cache',$menu_cache);
	    if ($menu_cache) {
		    if ( 'header' == $type ) {
		    	set_transient('ampforwp_header_menu', $sanitized_menu, 24*HOUR_IN_SECONDS );
		    }
		    elseif ('footer' == $type) {
		    	set_transient('ampforwp_footer_menu', $sanitized_menu, 24*HOUR_IN_SECONDS );
		    }
		}
    	return $sanitized_menu;
	}
}