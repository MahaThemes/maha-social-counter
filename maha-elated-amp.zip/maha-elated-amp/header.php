<?php 
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}
global $redux_builder_amp ?>
<?php amp_header_core() ?>
<?php
do_action( 'levelup_head');
?>
<?php do_action('ampforwp_admin_menu_bar_front'); ?>
<header class="header h_m h_m_1">
	<?php do_action('ampforwp_header_top_design4'); ?>
	<input type="checkbox" id="offcanvas-menu" class="tg" />
	<div class="hamb-mnu">
		<aside class="m-ctr">
			<div class="m-scrl">
				<div class="menu-heading clearfix">
					<label for="offcanvas-menu" class="c-btn"></label>
				</div>
				<!--end menu-heading-->

				<?php if ( elated_amp_menu(false) ) : ?>
				<nav class="m-menu">
					<?php elated_amp_menu();?>
				</nav>
				<!--end slide-menu -->
				<?php endif; ?>
				<?php do_action('ampforwp_after_amp_menu');?>

			</div><!-- /.m-srl -->
		</aside>
		<!--end menu-container-->
		<label for="offcanvas-menu" class="fsc"></label>
		<div class="cntr">
			<div class="head h_m_w">
				<?php  if(ampforwp_get_setting('ampforwp-amp-menu-swift') == true) {?>
				<div class="h-nav">
					<label for="offcanvas-menu" class="t-btn"></label>
				</div>
				<!--end menu-->
				<?php } ?>
				<div class="logo">
					<?php amp_logo(); ?>
				</div><!-- /.logo -->
				<div class="h-1">
					<?php if( true == $redux_builder_amp['amp-swift-search-feature'] ){ ?>
					<div class="h-srch h-ic">
						<a title="search" class="lb icon-src" href="#search"></a>
						<div class="lb-btn">
							<div class="lb-t" id="search">
								<?php amp_search();?>
								<a title="close" class="lb-x" href="#"></a>
							</div>
						</div>
					</div><!-- /.search -->
					<?php } ?>
					<?php do_action('ampforwp_header_elements') ?>
				</div>
				<div class="clearfix"></div>
			</div>
		</div>
	</div>
	<?php do_action('ampforwp_header_bottom_design4'); ?>
</header>
<?php
do_action("ampforwp_advance_header_layout_options");
// }
 ?>
<div class="content-wrapper">
	<div class="brand-wrap">
	<?php amp_logo(); ?>
	</div>

<?php
if(!ampforwp_levelup_compatibility('hf_builder_head') ){
 if($redux_builder_amp['primary-menu']){ ?>
	<div class="p-m-fl">
		<?php if ( amp_alter_menu(false) ) : ?>
		<div class="p-menu">
			<?php amp_alter_menu(true); ?>
		</div>
		<?php endif; ?>
		<?php do_action('ampforwp_after_primary_menu'); ?>
	</div>
	<?php } 
}?>