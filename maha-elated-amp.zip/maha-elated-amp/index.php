<?php 
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}
global $redux_builder_amp; ?>
<?php amp_header(); ?>
<div class="b-w">
	<div class="hmp">
		<?php do_action('ampforwp_home_above_loop') ?>
		<?php
	if (is_home() ){
		if (get_query_var( 'paged' ) ) {
			$paged = get_query_var('paged');
		} elseif ( get_query_var( 'page' ) ) {
			$paged = get_query_var('page');
		} else {
			$paged = 1;
		}
	}

		while(amp_loop('start')):
			$width 	= 346;
			$height = 188;
			?>
		<div class="fsp">
			<?php if( ampforwp_has_post_thumbnail() ) { 
				$args = array(
					"tag"=>'div',
					"tag_class"=>'image-container',
					'image_size'=>'full',
					'image_crop'=>'true',
					'image_crop_width'=>$width,
					'image_crop_height'=>$height,
					'responsive'=> true
				); ?>
				<div class="fsp-img">
					<?php amp_loop_image($args); ?>
				</div>
			<?php } ?>
			<div class="fsp-cnt">
				<div class="loop-meta">
					<?php amp_loop_category(); ?>
					<?php amp_loop_date(); ?>
				</div>
				<?php amp_loop_title(); ?>
				<?php if( ampforwp_check_excerpt() ) { 
					amp_loop_excerpt(20);
				}
				?>
			</div>
		</div>
		<?php endwhile; amp_loop('end');  ?>
		<?php do_action('ampforwp_loop_before_pagination') ?>
		<?php amp_pagination(); ?>
		<?php do_action('ampforwp_home_below_loop') ?>
	</div>
</div>

<?php amp_footer(); ?>