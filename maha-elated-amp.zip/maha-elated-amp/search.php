<?php 
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}
global $redux_builder_amp, $search_found;
amp_header() ?>
<div class="archive">
	<div class="arch-tlt">
		<?php amp_archive_title(); ?>
	</div>
	<div class="arch-dsgn">
		<div class="arch-psts">
			<?php amp_loop_template(); ?>
			<?php 
			if ( false == $search_found ){ ?>
				<div class="cntn-wrp srch ">
					<p><?php
						$message = '';
						$search_trans = ampforwp_get_setting('amp-translator-search-no-found');
						if(! empty( $search_trans ) ){
							$message = ampforwp_translation( ampforwp_get_setting('amp-translator-search-no-found'), 'It seems we can\'t find what you\'re looking for.');
						}
	 					echo esc_html($message); ?>
	 				</p>
			    </div>
 			<?php } ?>
			<?php amp_pagination(); ?>
		</div>
	</div>
</div>
<?php amp_footer()?>