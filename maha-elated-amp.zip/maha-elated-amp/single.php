<?php 
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}
global $redux_builder_amp; ?>
<?php amp_header(); ?>
<?php if(ampforwp_get_setting('single-design-type') == '1'){?>
<div class="sp sgl">
	<?php if(!checkAMPforPageBuilderStatus(get_the_ID())){ ?>
		<div class="cntr">
			<?php if ( true == $redux_builder_amp['ampforwp-bread-crumb'] ) {
				amp_breadcrumb();
			}?>
			<div class="loop-meta">
				<?php amp_categories_list();?>
				<?php amp_date();?>
			</div>
			<?php amp_title(); ?>
			<?php if ( function_exists('get_field') && get_field('post_lead') ) :?>
            <div class="tl-exc">
                <p><?php echo maha_string_limit_words( get_field('post_lead'), 34); ?></p>
			</div>
			<?php endif; ?>
		</div>
		<?php if ( ampforwp_has_post_thumbnail() ) { ?>
			<div class="sf-img">
				<?php amp_featured_image();?>
			</div>
		<?php } ?>
	<?php } ?>
	<div class="sp-cnt">
		<div class="cntr">
			<div class="sp-rl">
				<div class="sp-rt">
					<div class="cntn-wrp artl-cnt">
						
						<?php amp_content(); ?>

						<?php if( true == $redux_builder_amp['ampforwp-tags-single'] && amp_tags_list()){ ?>
							<div class="tags">
								<?php amp_tags_list();?>
							</div>
						<?php } ?>
					</div>
					<?php if(!checkAMPforPageBuilderStatus(get_the_ID())){ ?>
						<?php 
							$author_box = array();
							if( true == ampforwp_get_setting('amp-author-description') ) { ?>	
							<?php
							$author_box = array( 'avatar'=>true,
												'avatar_size'=>60,	
												'author_description'=>true,	
												'ads_below_the_author'=>true);
							if( true == ampforwp_get_setting('amp-author-bio-name')){
								$author_box['author_pub_name'] = true ;
							}
							amp_author_box( $author_box ); ?>	
						<?php } ?>
						
						<?php
						if ( true == ampforwp_get_setting('ampforwp-single-related-posts-switch') && !checkAMPforPageBuilderStatus(get_the_ID()) ) {
							$my_query = elated_ampforwp_related_post_loop_query();
							if( $my_query->have_posts() ) { $r_count = 1;?>
							<div class="srp">
								<div class="srp-wrap">
								<?php ampforwp_related_post(); ?>
									<ul class="clearfix">
										<?php
											while( $my_query->have_posts() ) {
											$my_query->the_post();
										?>
										<li class="<?php if ( has_post_thumbnail() ) { echo'has_thumbnail'; } else { echo 'no_thumbnail'; } ?>">
											<?php if ( true == $redux_builder_amp['ampforwp-single-related-posts-image'] ) { if(ampforwp_has_post_thumbnail()){?>
												<div class="rlp-image">     
														<?php ampforwp_get_relatedpost_image('full',array('image_crop'=>'true','image_crop_width'=>220,'image_crop_height'=>134) );?>
												</div>
											<?php } } ?>	
											<div class="rlp-cnt">
												<?php
												$show_excerpt_opt = ampforwp_get_setting('ampforwp-single-related-posts-excerpt');
												$argsdata = array(
														'show_author' =>  false,
														'show_excerpt' => $show_excerpt_opt
															);
												ampforwp_get_relatedpost_content($argsdata); ?> 
											</div>
										</li><?php
												do_action('ampforwp_between_related_post',$r_count);
															$r_count++;
										}
										} ?>
									</ul>
								</div>
							</div>
							<?php
							wp_reset_postdata();
						}
						?>

						<?php if( comments_open()) { ?>
						<div class="cmts">
							<?php amp_comments();?>
						</div>
						<?php } ?>
							<?php do_action('ampforwp_post_after_design_elements'); ?>
					<?php } ?>
				</div>
		    </div>
		</div>
	</div>
<?php 
do_action("ampforwp_single_design_type_handle_d1"); 
?>


</div>
<?php } // Single Design 1 ends here  ?>
<?php do_action("ampforwp_single_design_type_handle"); ?>
<?php amp_footer()?>