<?php if ( ! defined('ABSPATH')) {
	exit;
}

global $redux_builder_amp;
$plugin_url=plugin_dir_url(__FILE__);
$ds=ampforwp_get_setting('amp-design-selector');
$design="swift";

if($ds !=4) {
	$design="design-$ds";
}

preg_match('/maha-elated-amp/i', $plugin_url, $matches);
// if(count($matches)==0){
// 	$plugin_url = plugin_dir_url('accelerated-mobile-pages/accelerated-moblie-pages.php').'templates/design-manager/'.esc_attr($design).'/';
// }
$font_content='';
$font_content=ampforwp_get_setting('amp_font_selector_content_single');
$header_type=1;
$header_bg_color='rgba(255,255,255,1)';
// $header_bg_color=ampforwp_get_setting('swift-background-scheme', 'color');

$ampforwp_font_icon='swift-icons';

?>#wpadminbar li#wp-admin-bar-customize.hide-if-no-customize {display: none;}

<?php if(0==ampforwp_get_setting('ampforwp-google-font-switch')) {

	// Level up Condition starts ?>
	@font-face {
		font-family: 'Lora';
		font-display: swap;
		font-style: normal;
		font-weight: 400;
		src: local('Lora Regular'), local('Lora-Regular'), url('<?php echo $plugin_url ?>assets/fonts/lora/Lora-Regular.ttf');
	}

	@font-face {
		font-family: 'Lora';
		font-display: swap;
		font-style: normal;
		font-weight: 700;
		src: local('Lora Bold'), local('Lora-Bold'), url('<?php echo $plugin_url ?>assets/fonts/lora/Lora-Bold.ttf');
	}

	@font-face {
		font-family: 'HK Grotesk';
		font-display: swap;
		font-style: normal;
		font-weight: 400;
		src: local('HK Grotesk Regular'), local('HKGrotesk-Regular'), url('<?php echo $plugin_url ?>assets/fonts/hkg/HKGrotesk-Regular.ttf');
	}

	@font-face {
		font-family: 'HK Grotesk';
		font-display: swap;
		font-style: normal;
		font-weight: 600;
		src: local('HK Grotesk SemiBold'), local('HKGrotesk-SemiBold'), url('<?php echo $plugin_url ?>assets/fonts/hkg/HKGrotesk-SemiBold.ttf');
	}

	@font-face {
		font-family: 'HK Grotesk';
		font-display: swap;
		font-style: normal;
		font-weight: 700;
		src: local('HK Grotesk Bold'), local('HKGrotesk-Bold'), url('<?php echo $plugin_url ?>assets/fonts/hkg/HKGrotesk-Bold.ttf');
	}

	<?php // Level up Condition ends 
}
?>
<?php if(1==ampforwp_get_setting('content-font-family-enable') && ( !isset($redux_builder_amp['amp_font_selector_content_single']) || $redux_builder_amp['amp_font_selector_content_single']==1 || empty($redux_builder_amp['amp_font_selector_content_single']))) {
	if( !ampforwp_levelup_compatibility('levelup_theme_and_elementor')) {

		// Level up Condition starts ?>
		@font-face {
			font-family: 'HK Grotesk';
			font-display: swap;
			font-style: normal;
			font-weight: 400;
			src: local('HK Grotesk Regular'), local('HKGrotesk-Regular'), url('<?php echo $plugin_url ?>assets/fonts/hkg/HKGrotesk-Regular.ttf');
		}

		@font-face {
			font-family: 'HK Grotesk';
			font-display: swap;
			font-style: normal;
			font-weight: 600;
			src: local('HK Grotesk SemiBold'), local('HKGrotesk-SemiBold'), url('<?php echo $plugin_url ?>assets/fonts/hkg/HKGrotesk-SemiBold.ttf');
		}

		@font-face {
			font-family: 'HK Grotesk';
			font-display: swap;
			font-style: normal;
			font-weight: 700;
			src: local('HK Grotesk Bold'), local('HKGrotesk-Bold'), url('<?php echo $plugin_url ?>assets/fonts/hkg/HKGrotesk-Bold.ttf');
		}

		<?php
	}
}
?>
<?php
$hovercolor='#c39867';
if ( function_exists('get_field') && get_field('accent_color', 'elated_color') != '' ) {
	$hovercolor= get_field('accent_color', 'elated_color');
}

$swift_cs_color='#005be2';
$swift_btn_hvr_color='#fff';
$swift_cs=ampforwp_get_setting('swift-color-scheme');

if( !empty($swift_cs['color'])) {
	$swift_cs_color=$swift_cs['color'];
}

$swift_btn_hvr_color=ampforwp_get_setting('swift-btn-hover-color-scheme', 'color');

?>
body,
input,
.amp-related-posts-title,
.cmts h3 {
	<?php $theme=wp_get_theme();
	$fontFamilyBody="font-family: 'Arial', 'Helvetica', 'sans-serif';";

	if( !ampforwp_levelup_compatibility('levelup_theme') && 1 !=ampforwp_get_setting('content-font-family-enable')) {
		$fontFamilyBody="font-family: 'HK Grotesk', sans-serif;";

		if(ampforwp_get_setting('amp_font_selector_content_single') !=0 && !empty($redux_builder_amp['amp_font_selector_content_single'])) {
			$fontFamilyBody="font-family: '".$redux_builder_amp['amp_font_selector_content_single']."';";
		}
	}

	echo sanitize_text_field($fontFamilyBody);
	?>font-size: 16px;
	line-height:1.25;
}

h1,
h2,
h3,
h4,
h5,
h6,
blockquote p,
.related_link a,
.author-details .author-name,
.cmts .comment-author.vcard .fn {
	<?php $theme=wp_get_theme();
	$fontFamily="font-family: 'Arial', 'Helvetica', 'sans-serif';";

	if( !ampforwp_levelup_compatibility('levelup_theme') && 1 !=ampforwp_get_setting('ampforwp-google-font-switch')) {
		$fontFamily="font-family: 'Lora', 'Helvetica', 'sans-serif';";

		if(ampforwp_get_setting('amp_font_selector') !=0 && !empty($redux_builder_amp['amp_font_selector'])) {
			$fontFamily="font-family: '".$redux_builder_amp['amp_font_selector']."';";
		}
	}

	echo sanitize_text_field($fontFamily);
	?>
}

ol,
ul {
	list-style-position: inside
}

p,
ol,
ul,
figure {
	margin: 0 0 1em;
	padding: 0;
}

a,
a:active,
a:visited {
	text-decoration: none;
}

pre {
	white-space: pre-wrap;
}

.left {
	float: left
}

.right {
	float: right
}

.hidden,
.hide,
.logo .hide {
	display: none
}

.screen-reader-text {
	border: 0;
	clip: rect(1px, 1px, 1px, 1px);
	clip-path: inset(50%);
	height: 1px;
	margin: -1px;
	overflow: hidden;
	padding: 0;
	position: absolute;
	width: 1px;
	word-wrap: normal;
}

.clearfix {
	clear: both
}

.amp-wp-unknown-size img {
	object-fit: contain;
}

.amp-wp-enforced-sizes {
	max-width: 100%
}

html,
body,
div,
span,
object,
iframe,
h1,
h2,
h3,
h4,
h5,
h6,
p,
blockquote,
pre,
abbr,
address,
cite,
code,
del,
dfn,
em,
img,
ins,
kbd,
q,
samp,
small,
strong,
sub,
sup,
var,
b,
i,
dl,
dt,
dd,
ol,
ul,
li,
fieldset,
form,
label,
legend,
table,
caption,
tbody,
tfoot,
thead,
tr,
th,
td,
article,
aside,
canvas,
details,
figcaption,
figure,
footer,
header,
hgroup,
menu,
nav,
section,
summary,
time,
mark,
audio,
video {
	margin: 0;
	padding: 0;
	border: 0;
	outline: 0;
	font-size: 100%;
	vertical-align: baseline;
	background: transparent
}

body {
	line-height: 1
}

article,
aside,
details,
figcaption,
figure,
footer,
header,
hgroup,
menu,
nav,
section {
	display: block
}

nav ul {
	list-style: none
}

blockquote, q {
	quotes: none
}

blockquote p:last-child {
	margin-bottom: 0;
}

blockquote:before,
blockquote:after,
q:before,
q:after {
	content: none
}
blockquote {
	margin-top: -2px;
	margin-bottom: 1.8em;
	padding-bottom: 1.3em;
	border-bottom: 1px solid <?php if ( function_exists('get_field') && get_field('text_color_01', 'elated_color') != '' ) { echo get_field('text_color_01', 'elated_color'); } else { echo '#e8e8e8'; } ?>;
}

blockquote p {
	font-size: 1.1em;
	font-style: italic;
	line-height: 1.7;
	position: relative;
	padding: 30px 0 0 0;
}

blockquote p:before {
	content: "\201C";
	font-family: serif;
	display: block;
	font-weight: 700;
	font-size: 4em;
	line-height: 0.1em;
	margin-bottom: 10px;
	opacity: 0.2;
	font-style: normal;
}

blockquote cite {
	display: block;
    padding-left: 30px;
    position: relative;
}
blockquote cite:before {
	content: '';
	border-bottom: 2px solid <?php if ( function_exists('get_field') && get_field('text_color_01', 'elated_color') != '' ) { echo get_field('text_color_01', 'elated_color'); } else { echo '#e8e8e8'; } ?>;
    width: 20px;
    display: block;
    margin: 0em 0 -1em -30px;
}

a {
	margin: 0;
	padding: 0;
	font-size: 100%;
	vertical-align: baseline;
	background: transparent
}

table {
	border-collapse: collapse;
	border-spacing: 0
}

hr {
	display: block;
	height: 1px;
	border: 0;
	border-top: 1px solid <?php if ( function_exists('get_field') && get_field('text_color_01', 'elated_color') != '' ) { echo get_field('text_color_01', 'elated_color'); } else { echo '#e8e8e8'; } ?>;
	margin: 1.7em 0;
	padding: 0
}

input,
select {
	vertical-align: middle
}

*,
*:after,
*:before {
	box-sizing: border-box;
	-webkit-box-sizing: border-box;
	-moz-box-sizing: border-box;
	-ms-box-sizing: border-box;
	-o-box-sizing: border-box;
}

.alignright {
	float: right;
	margin-left: 1.6em;
	margin-bottom: 1.2em;
}

.alignleft {
	display: left;
	margin-right: 1.6em;
    margin-bottom: 1.2em;
}

.aligncenter {
	display: block;
	margin-left: auto;
	margin-right: auto;
}

@media(max-width:480px) {
	.alignleft,
	.alignright {
		float: none;
		display: block;
		margin: 0 0 1.7em 0;
	}
	amp-img.amp-wp-enforced-sizes[layout=intrinsic] > amp-img ~ img, amp-img.amp-wp-unknown-size > amp-img ~ img{
		object-fit: cover;
	}
}

amp-img {
	border-radius: 4px;
}
amp-iframe {
	max-width: 100%;
	margin-bottom: 20px;
}
amp-carousel{
	margin-bottom:1.7em;
}
.cls-btn:after{
	padding: 15px 10px;
    content: "\e5cd";
	font-family: 'icomoon';
	margin-right: -5px;
}
amp-wistia-player {
	margin: 5px 0;
}

.wp-caption {
	padding: 0;
}

figcaption,
.wp-caption-text {
	font-size: 12px;
	line-height: 1.5em;
	margin: 0;
	padding: 0 10px .75em;
	text-align: center;
}

amp-carousel>amp-img>img {
	object-fit: contain;
}

.amp-carousel-container {
	position: relative;
	width: 100%;
	height: 100%;
}

.amp-carousel-img img {
	object-fit: contain;
}

amp-instagram {
	box-sizing: initial;
}

figure.aligncenter amp-img {
	margin: 0 auto;
}

.loop-meta {
	display: inline-block;
	list-style-type: none;
	margin-right: 10px;
	margin-bottom: 10px;
	text-transform: uppercase;
	letter-spacing: 0.5px;
}

.loop-meta>* {
	display: inline-block;
	font-size: 11px;
}

.loop-meta ul {
	list-style-type: none;
}

.loop-meta li {
	display: inline-block;
}

.loop-meta li~li:before {
	content: ', ';
}

.loop-meta>*~*:before {
	content: '';
	width: 1px;
	height: 0.75em;
	background: <?php if ( function_exists('get_field') && get_field('text_color_05', 'elated_color') != '' ) { echo get_field('text_color_05', 'elated_color'); } else { echo '#909090'; } ?>;
	display: inline-block;
	margin: 0 7px 0 4px;
	margin-bottom: 0em;
	opacity: 0.2;
}
.loop-meta .amp-category > span:not(.amp-cat){
	display: none;
}
.loop-meta a, .loop-meta {
	color: <?php if ( function_exists('get_field') && get_field('text_color_05', 'elated_color') != '' ) { echo get_field('text_color_05', 'elated_color'); } else { echo '#909090'; } ?>;
}

.cntn-wrp a {
	color: inherit;
	border-bottom: 1px solid <?php if ( function_exists('get_field') && get_field('accent_color', 'elated_color') != '' ) { echo get_field('accent_color', 'elated_color'); } else { echo '#c39867'; } ?>;
}

<?php global $post; ?>

.cntr {
	max-width: 1100px;
	margin: 0 auto;
	width: 100%;
	padding: 0 20px
}

	@font-face {
		font-family: 'icomoon';
		font-display: swap;
		font-style: normal;
		font-weight: normal;
		src: local('icomoon'), local('icomoon'), url('<?php echo $plugin_url ?>assets/icons/icomoon.ttf');
	}

	header .cntr {
		max-width: 100%;
	}

	.h_m {
		position: fixed;
		z-index: 999;
		top: 0;
		width: 100vw;
		display: inline-block;
		border-bottom: 1px solid <?php if ( function_exists('get_field') && get_field('text_color_01', 'elated_color') != '' ) { echo get_field('text_color_01', 'elated_color'); } else { echo '#e8e8e8'; } ?>;
		background: white;
	}

	.content-wrapper {}
	#wpadminbar ~ header ~ .content-wrapper .brand-wrap{
		margin-top: 46px;
	}
	.brand-wrap {
		padding: 15px 0;
		visibility: hidden !important;
		opacity: 0 !important;
	}

	<?php // Sickt CSS Ends ?>

	.h_m_w {
		width: 100%;
		clear: both;
		display: inline-flex;
		padding: 16px 0;
	}

	.icon-src:before {
		content: "\e8b6";
		font-family: 'icomoon';
		font-size: 23px;
	}

	.isc:after {
		content: "\e8cc";
		font-family: 'icomoon';
		font-size: 20px;
	}

	.amp-logo a {
		line-height: 0;
		display: inline-block;
		color: <?php if ( function_exists('get_field') && get_field('text_color_10', 'elated_color') != '' ) { echo get_field('text_color_1o', 'elated_color'); } else { echo '#222222'; } ?>;
	}

	.logo <?php if(is_single()) { ?>h2<?php } else { ?>h1<?php } ?> {
		margin: 0;
		font-size: 17px;
		font-weight: 700;
		text-transform: uppercase;
		display: inline-block;
	}

	.h-srch a {
		line-height: 1;
		display: block;
		color: <?php if ( function_exists('get_field') && get_field('text_color_10', 'elated_color') != '' ) { echo get_field('text_color_10', 'elated_color'); } else { echo '#222222'; } ?>;
	}

	.amp-logo amp-img {
		margin: 0 auto;
	}

	@media(max-width:480px) {
		.h-sing {
			font-size: 13px;
		}
	}

	.logo {
		z-index: 2;
		flex-grow: 1;
		align-self: center;
		text-align: center;
		line-height: 0;
	}

	.h-1 {
		display: flex;
		order: 1;
	}

	.h-nav {
		order: -1;
		align-self: center;
	}
	
		.lb-t {
			position: fixed;
			top: -50px;
			width: 100%;
			width: 100%;
			opacity: 0;
			overflow: hidden;
			z-index: 9;
			background: white;
		}

		a.lb-x {
			display: block;
			width: 50px;
			height: 50px;
			box-sizing: border-box;
			text-decoration: none;
			position: absolute;
			top: -80px;
			right: 5px;
			padding: 22px 10px;
			opacity: 0.5;
			-webkit-transition: .5s ease-in-out;
			transition: .5s ease-in-out;
			color: <?php if ( function_exists('get_field') && get_field('text_color_10', 'elated_color') != '' ) { echo get_field('text_color_10', 'elated_color'); } else { echo '#222222'; } ?>;
		}

		a.lb-x:after {
			content: "\e5cd";
			font-family: 'icomoon';
			font-size: 24px;
			line-height: 0;
			display: block;
			text-indent: 1px;
		}

		.lb-t:target {
			opacity: 1;
			top: 0;
			bottom: 0;
			left: 0;
			z-index: 2;
		}

		.lb-t:target img {
			max-height: 100%;
			max-width: 100%;
		}

		.lb-t:target a.lb-x {
			top: 7px;
		}

		.lb img {
			cursor: pointer;
		}

		.lb-btn form {
			position: absolute;
			top: 200px;
			left: 0;
			right: 0;
			margin: 0 auto;
			text-align: center;
		}

		.lb-btn #s {
			padding: 10px;
		}

		.lb-btn #amp-search-submit {
			padding: 10px;
			cursor: pointer;
		}

		.amp-search-wrapper {
			width: 80%;
			margin: 0 auto;
			position: relative;
		}

		.overlay-search:before {
			content: "\e8b6";
			font-family: 'icomoon';
			font-size: 20px;
			opacity: 0.3;
			position: absolute;
			right: 0;
			cursor: pointer;
			top: 4px;
			color: inherit;
		}

		.lb-btn #amp-search-submit {
			cursor: pointer;
			background: transparent;
			border: none;
			display: inline-block;
			width: 30px;
			height: 30px;
			opacity: 0;
			position: absolute;
			z-index: 100;
			right: 0;
			top: 0;
		}

		.lb-btn #s {
			padding: 10px;
			background: transparent;
			border: none;
			border-bottom: 1px solid <?php if ( function_exists('get_field') && get_field('text_color_01', 'elated_color') != '' ) { echo get_field('text_color_01', 'elated_color'); } else { echo '#e8e8e8'; } ?>;
			width: 100%;
			outline: none;
		}
		

		.tg,
		.fsc {
			display: none;
		}

		.fsc {
			width: 100%;
			height: -webkit-fill-available;
			position: fixed;
			cursor: pointer;
			top: 0;
			left: 0;
			z-index: 9;
		}

		.tg:checked+.hamb-mnu>.m-ctr {
			margin-left: 0;
		}

		.tg:checked+.hamb-mnu>.m-ctr .c-btn {
			position: fixed;
			right: 15px;
			top: 16px;
		}

		.tg:checked+.hamb-mnu>.cntr .logo {
			z-index: 100;
		}

		.m-ctr {
			margin-left: -100%;
			float: left;
		}

		.tg:checked+.hamb-mnu>.fsc {
			display: block;
			background: rgba(0, 0, 0, .5);
			height: 100%;
		}

		.t-btn,
		.c-btn {
			cursor: pointer;
			color: <?php if ( function_exists('get_field') && get_field('text_color_10', 'elated_color') != '' ) { echo get_field('text_color_10', 'elated_color'); } else { echo '#222222'; } ?>;
		}

		.t-btn:after {
			content: "\e5d2";
			font-family: "icomoon";
			font-size: 26px;
			display: inline-block;
			vertical-align: bottom;
		}

		.c-btn:after {
			content: "\e5cd";
			font-family: "icomoon";
			font-size: 24px;
			opacity: 0.5;
			line-height: 0;
			display: block;
			text-indent: 1px;
		}

		.c-btn {
			float: right;
			padding: 15px 5px;
			top: -80px;
			webkit-transition: .5s ease-in-out;
			transition: .5s ease-in-out;
		}

		.m-ctr {
			width: 100%;
			height: 100%;
			position: absolute;
			z-index: 99;
			padding: 50px 0% 100vh 0%;
			background:<?php if ( function_exists('get_field') && get_field('white_color', 'elated_color') != '' ) { echo get_field('white_color', 'elated_color'); } else { echo '#ffffff'; } ?>;
		}

		.m-menu {
			display: inline-block;
			width: 100%;
			padding: 20px;
			margin: 12px 0 0;
			border-top: 1px solid <?php if ( function_exists('get_field') && get_field('text_color_01', 'elated_color') != '' ) { echo get_field('text_color_01', 'elated_color'); } else { echo '#e8e8e8'; } ?>;
		}

		.m-scrl {
			overflow-y: scroll;
			display: inline-block;
			width: 100%;
			max-height: 94vh;
		}

		.m-menu .amp-menu .toggle:after {
			content: "\e313";
			font-family: 'icomoon';
			font-size: 1.4em;
			display: inline-block;
			top: 1px;
			padding: 5px;
			transform: rotate(270deg);
			right: -5px;
			left: auto;
			cursor: pointer;
			border-radius: 35px;
			opacity: 0.3;
		}

		.m-menu .amp-menu li.menu-item-has-children:after {
			display: none;
		}

		.m-menu .amp-menu li ul {
			font-size: 15px;
		}

		.m-menu .amp-menu {
			list-style-type: none;
			padding: 0;
		}

		.m-menu .amp-menu>li a {
			color: #222;
			padding: 12px 7px;
			margin-bottom:0;
			display:inline-block;
		}

		.menu-btn {
			margin-top: 30px;
			text-align: center;
		}

		.menu-btn a {
			color: #fff;
			border: 2px solid <?php if ( function_exists('get_field') && get_field('text_color_05', 'elated_color') != '' ) { echo get_field('text_color_05', 'elated_color'); } else { echo '#909090'; } ?>;;
			padding: 15px 30px;
			display: inline-block;
		}

		.amp-menu li.menu-item-has-children>ul>li {
			width: 100%;
		}

		.m-menu .amp-menu li.menu-item-has-children>ul {
			padding-left: 20px;
			margin-bottom: 2px;
		}

		.m-menu .amp-menu li.menu-item-has-children>ul>li {
			padding-left: 0;
			margin: 0;
		}

		.m-menu .link-menu .toggle {
			width: 100%;
			height: 100%;
			position: absolute;
			top: 0;
			right: 0;
			cursor: pointer;
		}

		.m-menu .amp-menu .sub-menu li:last-child {
			border: none;
		}

		.m-menu .amp-menu a {
			padding: 7px 15px;
		}

		.m-menu>li {
			font-size: 17px;
		}

		.amp-menu .toggle:after {
			position: absolute;
		}

		<?php if(true==ampforwp_get_setting('amp-rtl-select-option')) {
			?>.m-menu .toggle {float: left;}<?php
		} else {
			?>.m-menu .toggle {float: right;}<?php
		}

		?>.m-menu input {
			display: none
		}

		.m-menu .amp-menu [id^=drop]:checked+label+ul {
			display: block;
		}

		.m-menu .amp-menu [id^=drop]:checked+.toggle:after {
			transform: rotate(360deg);
		}
		<?php


	?>.hamb-mnu ::-webkit-scrollbar {
		display: none;
	}

	<?php //primary menu
	$pmenu_bg_clr=ampforwp_get_setting('primary-menu-background-scheme', 'rgba');
	$pmenu_text_clr=ampforwp_get_setting('primary-menu-text-scheme', 'rgba');

	if(empty($pmenu_bg_clr)) {
		$pmenu_bg_clr='rgba(239, 239, 239,1)';
	}

	if(empty($pmenu_text_clr)) {
		$pmenu_text_clr='rgba(53, 53, 53,1)';
	}
	?>

<?php //Home and Archive

if(ampforwp_is_home() || is_archive() || is_search() || ampforwp_is_blog()) {?>
	.hmp {
		margin-top: 5px;
		display: inline-block;
		width: 100%;
	}

	.loop-wrapper {
		display: flex;
		flex-wrap: wrap;
	}

	.fsp-cnt p {
		font-size:16px;
		line-height:1.6;
		word-break: break-word;
	}
	.fsp-cnt p a{
		display: block;
		font-size: 11px;
		text-transform: uppercase;
		margin-top: 12px;
		color: <?php echo $hovercolor; ?>;
		letter-spacing: 0.5px;
	}

	.fsp h2 a,
	.fsp h3 a {
		color: <?php if ( function_exists('get_field') && get_field('text_color_10', 'elated_color') != '' ) { echo get_field('text_color_10', 'elated_color'); } else { echo '#222222'; } ?>;
	}

	.fsp {
		padding: 20px;
		flex-basis: calc(33.33% - 30px);
	}

	.fsp-img {
		margin-bottom: 16px;
		border-radius: 4px;
		overflow: hidden;
	}

	.fsp h2,
	.fsp h3 {
		margin: 0 0 10px 0;
		font-size: 20px;
		line-height: 1.4;
		font-weight: 600;
	}

	.at-dt {
		font-size: 11px;
		color: <?php if ( function_exists('get_field') && get_field('text_color_05', 'elated_color') != '' ) { echo get_field('text_color_05', 'elated_color'); } else { echo '#909090'; } ?>;
		margin: 12px 0 9px 0;
		display: inline-flex;
	}

	.pt-dt {
		font-size: 11px;
		color: #757575;
		margin: 8px 0 0 0;
		display: inline-flex;
	}

	.arch-tlt {
		padding: 25px 0;
		margin-bottom: 5px;
		display: inline-block;
		width: 100%;
		text-align: center;
    	background: <?php if ( function_exists('get_field') && get_field('text_color_01', 'elated_color') != '' ) { echo get_field('text_color_01', 'elated_color'); } else { echo '#e8e8e8'; } ?>;
	}

	.amp-archive-title,
	.amp-loop-label {
		font-weight: 600;
		text-align: center;
		font-size: 19px;
	}

	.amp-archive-desc {
		font-size: 14px;
		margin: 8px 0 0 0;
		color: #333;
		line-height: 20px;
	}

	.author-img amp-img {
		border-radius: 50%;
		margin: 0 12px 10px 0;
		display: block;
		width: 50px;
	}

	.author-img {
		float: left;
	}

	.amp-sub-archives {
		margin: 10px 0 0 10px;
	}

	.amp-sub-archives ul li {
		list-style-type: none;
		display: inline-block;
		font-size: 12px;
		margin-right: 10px;
		font-weight: 500;
	}

	.amp-sub-archives ul li a {
		color: #005be2;
	}

	.loop-pagination {
		margin: 2.5em 0;
	}
	.loop-pagination > div{
		float: none !important;
		text-align: center;
	}

	.right a,
	.left a {
		color: <?php if ( function_exists('get_field') && get_field('text_color_10', 'elated_color') != '' ) { echo get_field('text_color_10', 'elated_color'); } else { echo '#222222'; } ?>;
		background: <?php if ( function_exists('get_field') && get_field('text_color_003', 'elated_color') != '' ) { echo get_field('text_color_003', 'elated_color'); } else { echo '#f8f8f8'; } ?>;
		padding: 17px 30px 15px;
		line-height: 1;
		border-radius: 50em;
		font-size: 13px;
		display: inline-block;
		text-transform: uppercase;
    	letter-spacing: 1px;
	}

	.right a:hover,
	.left a:hover {
		color: <?php if ( function_exists('get_field') && get_field('white_color', 'elated_color') != '' ) { echo get_field('white_color', 'elated_color'); } else { echo '#ffffff'; } ?>;
		background: <?php if ( function_exists('get_field') && get_field('accent_color', 'elated_color') != '' ) { echo get_field('accent_color', 'elated_color'); } else { echo '#c39867'; } ?>;
	}

	.cntn-wrp.srch p {
		margin: 30px 0 30px 0;
	}

	.cntn-wrp.srch {
		font-size: 18px;
		color: #000;
		line-height: 1.7;
		word-wrap: break-word;
	}

	@media(max-width:1110px) {
		.amppb-fluid .col {
			max-width: 95%
		}

		.sf-img .wp-caption-text {
			width: 100%;
			padding: 10px 40px;
		}
	}

	@media(max-width:768px) {
		.hmp {
			margin: 0;
		}

		.fsp {
			flex-basis: calc(100% - 0px);
		}

		.fsp-img {
			width: 40%;
			float: left;
			margin-right: 20px;
		}

		.fsp-cnt {
			width: 54%;
			float: left;
		}

		.at-dt {
			margin: 10px 0 0 0;
		}

		.hmp .loop-wrapper {
			margin-top: 0;
		}

		.amp-loop-label {
			font-size: 16px;
		}

	}

	@media(max-width:480px) {
		.cntr.b-w {
			padding: 0;
		}

		.at-dt {
			margin: 7px 0 0 0;
		}

		.right,
		.left {
			float: none;
			text-align: center;
		}

		.right {
			margin-bottom: 30px;
		}

		.fsp-img {
			width: 100%;
			float: none;
			margin-right: 0;
		}

		.fsp-cnt {
			width: 100%;
			float: none;
		}

		.tg:checked+.hamb-mnu>.m-ctr .c-btn {
			position: fixed;
			right: 15px;
			top: 15px;
		}
	}

	@media(max-width:425px) {
		.hmp .loop-wrapper {
			margin: 0;
		}

		.hmp .fsp {
			flex-basis: calc(100% - 0px);
		}

		.amp-archive-title,
		.amp-loop-label {
			padding: 0 20px;
		}

		.amp-sub-archives {
			margin: 10px 0 0 30px;
		}

		.author-img {
			padding-left: 20px;
		}

		.amp-archive-desc {
			padding: 0 20px;
		}

		.loop-pagination {
			margin: 15px 0 15px 0;
		}
	}

	@media(max-width:320px) {

		.right a,
		.left a {
			padding: 10px 30px 14px;
		}
	}

	<?php
}

?><?php if( !ampforwp_levelup_compatibility('levelup_elementor')) {
	// Level up Condition starts?>
	<?php //page and frontpage
	if(is_page() || ampforwp_is_front_page() || ampforwp_polylang_front_page()) { ?>
		.sp {
			width: 100%;
			margin-top: 20px;
			display: inline-block;
		}

		.amp-post-title {
			font-size: 26px;
			line-height: 1.4em;
			color: #222222;
			margin: 0 0 25px 0;
			text-align: center;
		}
		
		.sf-img{
			margin-bottom: 1.8em;
			border-radius: 4px;
			overflow: hidden;
		}

		.sf-img .wp-caption-text{
			display: none;
		}

		.cntn-wrp {
			font-size: 17px;
			color: #000;
			line-height: 1.7;
		}

		.cntn-wrp small {
			font-size: 11px;
			line-height: 1.2;
			color: #111;
		}

		.cntn-wrp p,
		.cntn-wrp ul,
		.cntn-wrp ol {
			margin: 0 0 1.8em 0;
			word-break: break-word;
		}

		.form-submit #submit {
			background-color: #005be2;
			font-size: 14px;
			text-align: center;
			border-radius: 3px;
			font-weight: 500;
			color: #fff;
			cursor: pointer;
			margin: 0;
			border: 0;
			padding: 11px 21px;
		}

		#respond p {
			margin: 12px 0;
		}

		<?php if( !checkAMPforPageBuilderStatus(ampforwp_get_the_ID()) && ampforwp_get_comments_status() && true==ampforwp_get_setting('wordpress-comments-support')) { ?>

			.cmts {
				width: 100%;
				display: inline-block;
				clear: both;
				margin-top: 40px;
			}

			.amp-comment-button {
				color: <?php if ( function_exists('get_field') && get_field('text_color_10', 'elated_color') != '' ) { echo get_field('text_color_10', 'elated_color'); } else { echo '#222222'; } ?>;
				background: <?php if ( function_exists('get_field') && get_field('text_color_003', 'elated_color') != '' ) { echo get_field('text_color_003', 'elated_color'); } else { echo '#f8f8f8'; } ?>;
				padding: 17px 30px 15px;
				line-height: 1;
				border-radius: 50em;
				font-size: 13px;
				display: inline-block;
				text-transform: uppercase;
				letter-spacing: 1px;
			}

			.amp-comment-button a {
				color: #fff;
				display: block;
				padding: 7px 0 8px 0;
			}

			.comment-form-comment #comment {
				border-color: #ccc;
				width: 100%;
				padding: 20px;
			}

			.cmts h3 {
				margin: 0;
				font-size: 12px;
				padding-bottom: 6px;
				border-bottom: 1px solid #eee;
				font-weight: 400;
				letter-spacing: 0.5px;
				text-transform: uppercase;
				color: #444;
			}

			.cmts h3:after {
				content: "";
				display: block;
				width: 115px;
				border-bottom: 1px solid #005be2;
				position: relative;
				top: 7px;
			}

			.cmts ul {
				margin-top: 16px;
			}

			.cmts ul li {
				list-style: none;
				margin-bottom: 20px;
				padding-bottom: 20px;
				border-bottom: 1px solid #eee;
			}

			.cmts .amp-comments-wrapper ul .children {
				margin-left: 30px;
			}

			.cmts .comment-author.vcard .says {
				display: none;
			}

			.cmts .comment-author.vcard .fn {
				font-size: 14px;
				font-weight: 700;
				color: #222;
			}

			.cmts .comment-metadata {
				font-size: 11px;
				margin-top: 6px;
				text-transform: uppercase;
			}

			.amp-comments-wrapper ul li:hover .comment-meta .comment-metadata a {
				color: <?php echo ampforwp_sanitize_color($swift_cs_color) ?>;
				;
			}

			.cmts .comment-metadata a {
				color: #999;
			}

			.comment-content {
				margin-top: 6px;
				width: 100%;
				display: inline-block;
			}

			.comment-content p {
				font-size: 14px;
				color: #333;
				line-height: 22px;
				font-weight: 400;
				margin: 0;
			}

			.comment-meta amp-img {
				float: left;
				margin-right: 12px;
				border-radius: 50%;
				margin-top: -4px;
				width: 40px;
			}

			<?php
		}

	}

	?><?php
}

// Level Condition Ends
if(is_page() || ampforwp_is_front_page()) { ?>
	.pg table {
		width: 100%;
		margin-bottom: 25px;
		overflow-x: auto;
		word-break: normal;
	}

	.pg td {
		padding: 0.5em 1em;
		border: 1px solid #ddd;
	}

	.pg tr:nth-child(odd) td {
		background: <?php if ( function_exists('get_field') && get_field('text_color_01', 'elated_color') != '' ) { echo get_field('text_color_01', 'elated_color'); } else { echo '#e8e8e8'; } ?>;
	}

	@media(max-width:767px) {
		.pg table {
			display: -webkit-box;
		}
	}

	<?php
}

// page table css ends ?>
<?php //AMP Woocommerce condition starts

if( !ampforwp_woocommerce_conditional_check()) {
	?><?php if(is_singular()) {
		?>

		/** Pre tag Styling **/
		pre {
			padding: 30px 15px;
			background: <?php if ( function_exists('get_field') && get_field('text_color_01', 'elated_color') != '' ) { echo get_field('text_color_01', 'elated_color'); } else { echo '#e8e8e8'; } ?>;
			white-space: pre-wrap;
			font-size: 14px;
			color: <?php if ( function_exists('get_field') && get_field('text_color_08', 'elated_color') != '' ) { echo get_field('text_color_08', 'elated_color'); } else { echo '#4e4e4e'; } ?>;
			border-left: 3px solid;
			border-color: <?php if ( function_exists('get_field') && get_field('text_color_01', 'elated_color') != '' ) { echo get_field('text_color_01', 'elated_color'); } else { echo '#e8e8e8'; } ?>;
			margin-bottom: 20px;
		}

		.cntn-wrp {
			<?php
			$fontFamilyBody="font-family: 'HK Grotesk', sans-serif;";
			echo sanitize_text_field($fontFamilyBody);
			?>
		}

		<?php
	}

	?><?php //if(ampforwp_get_setting('single-design-type')=='1'|| ampforwp_get_setting('single-design-type')=='4') {
	?><?php // Single

	if(is_single() && !checkAMPforPageBuilderStatus(ampforwp_get_the_ID())) { ?>
		table {
			display: -webkit-box;
			overflow-x: auto;
			word-break: normal;
		}

		.artl-cnt table {
			margin: 0 auto;
			text-align: center;
			width: 100%;
		}

		p.nocomments {
			padding: 10px;
			color: <?php if ( function_exists('get_field') && get_field('white_color', 'elated_color') != '' ) { echo get_field('white_color', 'elated_color'); } else { echo '#ffffff'; } ?>;
		}

		.tl-exc {
			font-size: 17px;
			color: <?php if ( function_exists('get_field') && get_field('text_color_10', 'elated_color') != '' ) { echo get_field('text_color_10', 'elated_color'); } else { echo '#222222'; } ?>;
			line-height: 1.7;
			margin-top: 10px;
		}

		.cntr ~ .sf-img amp-img{
			border-radius: 0;
		}

		.sp {
			width: 100%;
			margin-top: 20px;
			display: inline-block;
		}
		.sp > .sf-img .wp-caption-text{
			display: none;
		}

		.amp-post-title {
			font-size: 26px;
			line-height: 1.4em;
			color: <?php if ( function_exists('get_field') && get_field('text_color_10', 'elated_color') != '' ) { echo get_field('text_color_10', 'elated_color'); } else { echo '#222222'; } ?>;
			margin: 0 0 10px 0;
		}

		.sf-img {
			width: 100%;
			display: inline-block;
			height: auto;
			margin-top: 1em;
		}

		.sf-img figure {
			margin: 0;
		}

		.sf-img .wp-caption-text {
			<?php if (ampforwp_get_setting('swift-featued-image-type')==1) {
				?>width: 1100px;
				<?php
			}

			if (ampforwp_get_setting('swift-featued-image-type')==2) {
				?>width: 100%;
				<?php
			}

			?>text-align: left;
			margin: 0 auto;
			color: <?php if ( function_exists('get_field') && get_field('text_color_08', 'elated_color') != '' ) { echo get_field('text_color_08', 'elated_color'); } else { echo '#4e4e4e'; } ?>;
			font-size: 14px;
			line-height:20px;
			font-weight: 500;
			border-bottom: 1px solid <?php if ( function_exists('get_field') && get_field('text_color_01', 'elated_color') != '' ) { echo get_field('text_color_01', 'elated_color'); } else { echo '#e8e8e8'; } ?>;
			padding: 15px 0;
		}

		.sf-img .wp-caption-text:before {
			content: "\e412";
			font-family: 'icomoon';
			font-size: 24px;
			position: relative;
			top: 4px;
			opacity: 0.4;
			margin-right: 5px;
		}

		<?php if ( !checkAMPforPageBuilderStatus(ampforwp_get_the_ID())) {
			?>.sp-cnt {
				margin-top: 1.6em;
				clear: both;
				width: 100%;
				display: inline-block;
			}

			.sp-rl {}

			.sp-rt {
				flex-direction: column;
				justify-content: space-around;
				order: 1;
			}

			<?php
		}

		?><?php if(true==ampforwp_get_setting('enable-single-post-social-icons') || true==ampforwp_get_setting('amp-author-name') || true==ampforwp_get_setting('swift-date') || true==ampforwp_get_setting('ampforwp-single-related-posts-switch')) {
			?>.sp-lt {
				display: flex;
				flex-direction: column;
				flex: 1 0 20%;
				order: 0;
				max-width: 237px;
			}

			<?php
		}

		?>.ss-ic,
		.sp-athr,
		.amp-tags,
		.post-date {
			padding-bottom: 1.5em;
		}

		.amp-tags span:not(.amp-tag){
			display: none;
		}

		.shr-txt,
		.athr-tx,
		.related-title,
		.r-pf h3 {
			margin-bottom: 12px;
		}

		.shr-txt,
		.athr-tx,
		.r-pf h3,
		.amp-related-posts-title,
		.post-date,
		.related-title {
			display: block;
		}

		.shr-txt,
		.athr-tx,
		.r-pf h3,
		.amp-related-posts-title,
		.post-date,
		.related-title {
			text-transform: uppercase;
			font-size: 13px;
			color: <?php if ( function_exists('get_field') && get_field('text_color_10', 'elated_color') != '' ) { echo get_field('text_color_10', 'elated_color'); } else { echo '#222222'; } ?>;
			font-weight: 400;
		}

		.cmts h3,
		.amp-related-posts-title{
			text-align: center;
			margin-bottom: 2em;
			letter-spacing: 1px;
		}

		.loop-date,
		.post-edit-link {
			display: inline-block;
		}

		.post-date .post-edit-link {
			color: <?php if ( function_exists('get_field') && get_field('accent_color', 'elated_color') != '' ) { echo get_field('accent_color', 'elated_color'); } else { echo '#c39867'; } ?>;
			float: right;
		}

		.post-date .post-edit-link:hover {
			color: <?php if ( function_exists('get_field') && get_field('accent_color', 'elated_color') != '' ) { echo get_field('accent_color', 'elated_color'); } else { echo '#c39867'; } ?>;
		}

		.sp-athr,
		.amp-tags,
		.post-date {
			margin-top: 20px;
		}

		.sp-athr .author-details a,
		.sp-athr .author-details,
		.amp-tags span a,
		.amp-tag {
			font-size: 15px;
			line-height: 1.5;
			color: <?php if ( function_exists('get_field') && get_field('accent_color', 'elated_color') != '' ) { echo get_field('accent_color', 'elated_color'); } else { echo '#c39867'; } ?>;
			border: none;
		}

		.amp-tags .amp-tag{
			text-transform: lowercase;
		}

		.amp-tags .amp-tag:after {
			content: ",";
			display: inline-block;
			padding: 0 7px 0 0;
			position: relative;
			top: -1px;
			font-size: 12px;
		}

		.amp-tags .amp-tag:last-child:after {
			display: none;
		}

		.ss-ic li:before {
			border-radius: 2px;
			text-align: center;
			padding: 4px 6px;
		}

		.sgl table {
			width: 100%;
			margin-bottom: 25px;
		}

		.sgl td {
			padding: 0.5em 1em;
			border: 1px solid #ddd;
		}

		.sgl tr:nth-child(odd) td {
			background: #f7f7f7;
		}

		<?php // Social Sharing Conditional CSS

		if($redux_builder_amp['swift-social-position']=='below-content') {
			?>.shr-txt {
				display: none;
			}

			.sp-athr {
				margin-top: 0;
			}

			.sp-rt .ss-ic {
				padding-bottom: 10px;
				margin-bottom: 20px;
			}

			<?php
		}

		?>.cntn-wrp {
			font-size: 17px;
			color: <?php if ( function_exists('get_field') && get_field('text_color_10', 'elated_color') != '' ) { echo get_field('text_color_10', 'elated_color'); } else { echo '#222222'; } ?>;
			line-height: 1.7;
			word-break: break-word;
		}

		.cntn-wrp small {
			font-size: 11px;
			line-height: 1.2;
			color: #111;
		}

		.cntn-wrp p,
		.cntn-wrp ul,
		.cntn-wrp ol {
			margin: 0 0 1.8em 0;
			word-break: break-word;
		}

		.cntn-wrp .wp-block-image,
		.wp-block-embed {
			margin: 15px 0;
		}

		.artl-cnt ul li,
		.artl-cnt ol li {
			list-style-type: none;
			position: relative;

			<?php if(true==ampforwp_get_setting('amp-rtl-select-option')) {
				?>padding-right: 20px;
				<?php
			}

			else {
				?>padding-left: 20px;
				<?php
			}

			?>
		}

		.artl-cnt ul li:before {
			content: "";
			display: inline-block;
			width: 5px;
			height: 5px;
			background: <?php if ( function_exists('get_field') && get_field('text_color_10', 'elated_color') != '' ) { echo get_field('text_color_10', 'elated_color'); } else { echo '#222222'; } ?>;
			position: absolute;
			top: 12px;

			<?php if(true==ampforwp_get_setting('amp-rtl-select-option')) {
				?>right: 0;
				<?php
			}

			else {
				?>left: 0;
				<?php
			}

			?>
		}

		.artl-cnt ol li {
			counter-increment: step-counter;
		}

		.artl-cnt ol li::before {
			content: counter(step-counter);
			font-size: 16px;
			color: <?php if ( function_exists('get_field') && get_field('text_color_10', 'elated_color') != '' ) { echo get_field('text_color_10', 'elated_color'); } else { echo '#222222'; } ?>;
			position: absolute;

			<?php if(true==ampforwp_get_setting('amp-rtl-select-option')) {
				?>right: 0;
				<?php
			}

			else {
				?>left: 0;
				<?php
			}

			?>line-height: 1.2;
			top: 6px;
		}

		.sp-rt p strong,
		.pg p strong {
			font-weight: 700;
		}

		@supports (-webkit-overflow-scrolling: touch) {
			.m-ctr {
				overflow: initial;
			}
		}

		@supports not (-webkit-overflow-scrolling: touch) {
			.m-ctr {
				overflow: scroll;
			}
		}

		.m-scrl {
			display: inline-block;
			width: 100%;
			max-height: 94vh;
		}

		
			.srp {
				margin-top: 2em;
				border-top: 1px solid <?php if ( function_exists('get_field') && get_field('text_color_01', 'elated_color') != '' ) { echo get_field('text_color_01', 'elated_color'); } else { echo '#e8e8e8'; } ?>;
				padding-top: 2em;
			}

			.srp .rlp-image {
				margin-bottom: 1.2em;
			}
			.srp .amp-related-posts amp-img {
				float: left;
				width: 100%;
				margin: 0;
				height: 100%;
			}

			.srp ul li {
				display: inline-block;
				margin-bottom: 2.4em;
				list-style-type: none;
				width: 100%;
			}

			.srp ul li:last-child {
				margin-bottom: 0;
			}

			.has_thumbnail:hover {
				opacity: 0.7;
			}

			.has_thumbnail:hover .related_link a {
				color: <?php if ( function_exists('get_field') && get_field('accent_color', 'elated_color') != '' ) { echo get_field('accent_color', 'elated_color'); } else { echo '#c39867'; } ?>;
			}

	}

	// Related Posts Desing 3 Ends ?>
	.related_link {
		margin-top: 1.4em;
	}
	
	.related_link a {
		color: <?php if ( function_exists('get_field') && get_field('text_color_10', 'elated_color') != '' ) { echo get_field('text_color_10', 'elated_color'); } else { echo '#222222'; } ?>;
		font-weight: 700;
		font-size: 20px;
		line-height: 1.3em;
	}

	.related_link p {
		color: <?php if ( function_exists('get_field') && get_field('text_color_10', 'elated_color') != '' ) { echo get_field('text_color_10', 'elated_color'); } else { echo '#222222'; } ?>;
		font-size: 16px;
		line-height: 1.6;
		word-break: break-word;
		margin-top: 10px;
	}

	.amp-related-posts ul {
		list-style-type: none;
	}

	.r-pf {
		margin-top: 40px;
		display: inline-block;
		width: 100%;
	}

	<?php if(true==ampforwp_get_setting('amp-author-description')) {
		?>.sp-rt .amp-author {
			display: block;
			width: 100%;
		}

		.sp-rt .author-details a {
			color: #222;
			font-size: 14px;
			font-weight: 500;
		}

		.sp-rt .author-details a:hover {
			color: <?php echo $hovercolor; ?>;
			text-decoration: underline;
		}

		.amp-author-image amp-img {
			border-radius: 50em;
			margin: 0 auto 1em;
			display: block;
			width: 50px;
		}

		.author-details {
			text-align: center;
		}
		.author-details .author-name{
			font-weight: 700;
		}
		.author-details p {
			margin: 1em 0 0;
			font-size: 17px;
    		line-height: 1.6em;
			color: #222222;
		}

		<?php
	}

	?>#pagination {
		margin-top: 30px;
		border-top: 1px dotted <?php if ( function_exists('get_field') && get_field('text_color_01', 'elated_color') != '' ) { echo get_field('text_color_01', 'elated_color'); } else { echo '#e8e8e8'; } ?>;
		padding: 20px 5px 0 5px;
		;
		font-size: 16px;
		line-height: 24px;
		font-weight: 400;
	}

	.next {
		float: right;
		width: 45%;
		text-align: right;
		position: relative;
		margin-top: 10px;
	}

	.next a,
	.prev a {
		color: <?php if ( function_exists('get_field') && get_field('text_color_010', 'elated_color') != '' ) { echo get_field('text_color_10', 'elated_color'); } else { echo '#222222'; } ?>;
	}

	.prev {
		float: left;
		width: 45%;
		position: relative;
		margin-top: 10px;
	}

	.prev span {
		text-transform: uppercase;
		font-size: 12px;
		color: <?php if ( function_exists('get_field') && get_field('text_color_08', 'elated_color') != '' ) { echo get_field('text_color_08', 'elated_color'); } else { echo '#4e4e4e'; } ?>;
		display: block;
		position: absolute;
		top: -26px;
	}

	.next span {
		text-transform: uppercase;
		font-size: 12px;
		color: <?php if ( function_exists('get_field') && get_field('text_color_08', 'elated_color') != '' ) { echo get_field('text_color_08', 'elated_color'); } else { echo '#4e4e4e'; } ?>;
		display: block;
		font-weight: 400;
		position: absolute;
		top: -26px;
		right: 0
	}

	.next:hover a,
	.prev:hover a {
		color: <?php echo $hovercolor; ?>;
	}

	.prev:after {
		border-left: 1px dotted #ccc;
		content: "";
		height: calc(100% - -10px);
		right: -50px;
		position: absolute;
		top: 50%;
		transform: translate(0, -50%);
		width: 2px;
	}

	<?php if ( !checkAMPforPageBuilderStatus(ampforwp_get_the_ID())) {
		?>.ampforwp_post_pagination {
			width: 100%;
			text-align: center;
			display: inline-block;
		}

		.ampforwp_post_pagination p {
			margin: 0;
			font-size: 18px;
			color: #444;
			font-weight: 500;
			margin-bottom: 10px;
		}

		.ampforwp_post_pagination p a {
			color: <?php if ( function_exists('get_field') && get_field('text_color_08', 'elated_color') != '' ) { echo get_field('text_color_08', 'elated_color'); } else { echo '#4e4e4e'; } ?>;
			padding: 0 10px;
		}

		<?php if(true==ampforwp_get_setting('wordpress-comments-support')) {
			?>.cmts {
				width: 100%;
				display: block;
				clear: both;
				margin-top: 2em;
				padding-top: 2em;
				border-top: 1px solid #ececec;
			}

			.amp-comment-button {
				color: <?php if ( function_exists('get_field') && get_field('text_color_10', 'elated_color') != '' ) { echo get_field('text_color_10', 'elated_color'); } else { echo '#222222'; } ?>;
				background: <?php if ( function_exists('get_field') && get_field('text_color_003', 'elated_color') != '' ) { echo get_field('text_color_003', 'elated_color'); } else { echo '#f8f8f8'; } ?>;
				padding: 17px 30px 15px;
				line-height: 1;
				border-radius: 50em;
				font-size: 13px;
				display: block;
				width: 100%;
				text-align: center;
				text-transform: uppercase;
				letter-spacing: 1px;
			}

			.form-submit #submit {
				background-color: #005be2;
				font-size: 14px;
				text-align: center;
				border-radius: 3px;
				font-weight: 500;
				color: #fff;
				cursor: pointer;
				margin: 0;
				border: 0;
				padding: 11px 21px;
			}

			#respond p {
				margin: 12px 0;
			}

			.amp-comment-button a {
				color: #222222;
				display: block;
			}

			.comment-form-comment #comment {
				border-color: #ccc;
				width: 100%;
				padding: 20px;
			}

			.cmts h3 {
				margin: 0;
				font-size: 12px;
				padding-bottom: 6px;
				font-weight: 400;
				letter-spacing: 0.5px;
				text-transform: uppercase;
				color: #444;
			}

			.cmts ul {
				margin-top: 16px;
			}

			.cmts ul li {
				list-style: none;
				margin-bottom: 20px;
				padding-bottom: 20px;
				border-bottom: 1px solid #eee;
			}

			.cmts .amp-comments-wrapper ul .children {
				margin-left: 9%;
			}

			.cmts .comment-author.vcard .says {
				display: none;
			}

			.cmts .comment-author.vcard .fn {
				font-size: 14px;
				font-weight: 700;
				color: #222;
			}

			.cmts .comment-metadata {
				font-size: 11px;
				margin-top: 6px;
				text-transform: uppercase;
			}

			.amp-comments-wrapper ul li:hover .comment-meta .comment-metadata a {
				color: <?php if ( function_exists('get_field') && get_field('accent_color', 'elated_color') != '' ) { echo get_field('accent_color', 'elated_color'); } else { echo '#c39867'; } ?>;
			}

			.cmts .comment-metadata a {
				color: #999;
			}

			.comment-content {
				margin-top: 6px;
				width: 100%;
				display: inline-block;
			}

			.comment-content p {
				font-size: 14px;
				color: #333;
				line-height: 22px;
				font-weight: 400;
				margin: 0;
			}

			.comment-meta amp-img {
				float: left;
				margin-right: 12px;
				border-radius: 50%;
				margin-top: -4px;
				width: 40px;
			}

			<?php
		}

		?>.sp-rt .amp-author {
			border-top: 1px solid <?php if ( function_exists('get_field') && get_field('text_color_01', 'elated_color') != '' ) { echo get_field('text_color_01', 'elated_color'); } else { echo '#e8e8e8'; } ?>;
			padding-top: 2em;
		}

		<?php
	}

	?>.cntn-wrp a {
		margin: 10px 0;
		border-bottom: 1px solid <?php if ( function_exists('get_field') && get_field('accent_color', 'elated_color') != '' ) { echo get_field('accent_color', 'elated_color'); } else { echo '#c39867'; } ?>;
	}

	.loop-wrapper {
		display: flex;
		flex-wrap: wrap;
		margin: -15px;
	}

	.fsp-cnt p {
		color: <?php if ( function_exists('get_field') && get_field('text_color_08', 'elated_color') != '' ) { echo get_field('text_color_08', 'elated_color'); } else { echo '#4e4e4e'; } ?>;
		font-size: 13px;
		line-height: 20px;
		letter-spacing: 0.10px;
		word-break: break-word;
	}

	.fsp h2 a,
	.fsp h3 a {
		color: <?php if ( function_exists('get_field') && get_field('text_color_10', 'elated_color') != '' ) { echo get_field('text_color_10', 'elated_color'); } else { echo '#222222'; } ?>;
	}

	.fsp {
		margin: 15px;
		flex-basis: calc(33.33% - 30px);
	}

	.fsp-img {
		margin-bottom: 10px;
	}

	.fsp h2,
	.fsp h3 {
		margin: 0 0 5px 0;
		font-size: 20px;
		line-height: 25px;
		font-weight: 600;
	}

	.pt-dt {
		font-size: 11px;
		color: <?php if ( function_exists('get_field') && get_field('text_color_08', 'elated_color') != '' ) { echo get_field('text_color_08', 'elated_color'); } else { echo '#4e4e4e'; } ?>;
		margin: 8px 0 0 0;
		display: inline-flex;
	}

		<?php // Comments Pagination 

		if(isset($redux_builder_amp['wordpress-comments-support']) && 1==$redux_builder_amp['wordpress-comments-support']) {
			?>.cmts-wrap {
				display: flex;
				width: 100%;
				margin-top: 30px;
				padding-bottom: 30px;
				border-bottom: 1px solid <?php if ( function_exists('get_field') && get_field('text_color_01', 'elated_color') != '' ) { echo get_field('text_color_01', 'elated_color'); } else { echo '#e8e8e8'; } ?>;
			}

			.cmts-wrap .page-numbers:after {
				display: none;
			}

			.cmts .page-numbers {
				margin: 0 10px;
			}

			.cmts .prev,
			.cmts .next {
				margin: 0 auto;
			}

			.cmts-wrap a {
				color: <?php if ( function_exists('get_field') && get_field('text_color_10', 'elated_color') != '' ) { echo get_field('text_color_10', 'elated_color'); } else { echo '#222222'; } ?>;
			}

			.cmts-wrap a:hover {
				color: <?php if ( function_exists('get_field') && get_field('accent_color', 'elated_color') != '' ) { echo get_field('accent_color', 'elated_color'); } else { echo '#c39867'; } ?>;
			}

			.cmts-wrap .current {
				color: <?php if ( function_exists('get_field') && get_field('accent_color', 'elated_color') != '' ) { echo get_field('accent_color', 'elated_color'); } else { echo '#c39867'; } ?>;
			}

			<?php
		}

		// Comments Pagination CSS Ends
		if (true==ampforwp_get_setting('ampforwp-disqus-comments-support')) {
			?>.amp-disqus-comments {
				text-align: center
			}

			.amp-disqus-comments amp-iframe,
			.amp-disqus-comments iframe {
				overflow: auto;
				overflow-y: scroll;
				-webkit-overflow-scrolling: touch;
			}

			.amp-disqus-comments iframe {
				width: 100%;
				height: 300px;
			}

			<?php
		}

		?>@media(max-width:1110px) {
			<?php if ( !checkAMPforPageBuilderStatus(ampforwp_get_the_ID())) {
				?>.cntr {
					width: 100%;
					padding: 0 20px;
				}

				.sp-rt {
					margin-left: 30px;
				}

				<?php
			}

			?>
		}

		@media(max-width:768px) {

			.sp-rl {
				display: inline-block;
				width: 100%;
			}

			<?php if(true==ampforwp_get_setting('enable-single-post-social-icons') || true==ampforwp_get_setting('amp-author-name') || true==ampforwp_get_setting('swift-date') || true==ampforwp_get_setting('ampforwp-single-related-posts-switch')) {
				?>.sp-lt {
					width: 100%;
					margin-top: 20px;
					max-width: 100%;
				}
			<?php } ?>

			.r-pf h3 {
				padding-top: 20px;
				border-top: 1px dotted <?php if ( function_exists('get_field') && get_field('text_color_01', 'elated_color') != '' ) { echo get_field('text_color_01', 'elated_color'); } else { echo '#e8e8e8'; } ?>;
			}

			.r-pf {
				margin-top: 20px;
			}

			<?php if(true==ampforwp_get_setting('wordpress-comments-support')) {
				?>.cmts {
					margin: 20px 0 20px 0;
				}

				<?php
			}

			?>.sp-rt {
				width: 100%;
				margin-left: 0;
			}

			#pagination {
				margin: 20px 0 20px 0;
				border-top: none;
			}

			/*.amp-post-title {
				padding-top: 10px;
			}*/

			.fsp {
				flex-basis: calc(100% - 30px);
			}

			.fsp-img {
				width: 40%;
				float: left;
				margin-right: 20px;
			}

			.fsp-cnt {
				width: 54%;
				float: left;
			}

			<?php if($redux_builder_amp['rp_design_type']=='1') { ?>

				.rlp-image {
					width: 200px;
					float: left;
					margin-right: 15px;
					display: flex;
					flex-direction: column;
				}

				.rlp-cnt {
					display: flex;
				}

				<?php
			}

			//Related post Design 1 CSS Ends
			if($redux_builder_amp['rp_design_type']=='2') {
				?>.srp ul li {
					flex-basis: calc(100% - 30px);
				}

				.srp li .rlp-image {
					width: 40%;
					float: left;
					margin-right: 20px;
				}

				.srp li .rlp-cnt {
					width: 54%;
					float: left;
				}

				<?php
			}

			//Related post Design 2 CSS Ends?>
			<?php if (checkAMPforPageBuilderStatus(get_the_ID())) {
				?>.sp-cnt {
					margin-top: 0;
				}

				<?php
			}

			?>
		}

		@media(max-width:480px) {
			.loop-wrapper {
				margin-top: 15px;
			}

			.cntn-wrp p {
				line-height: 1.65;
			}

			.related_posts .has_related_thumbnail {
				width: 100%;
			}

			.rlp-image {
				width: 100%;
				float: none;
				margin-right: 0;
			}

			.rlp-cnt {
				width: 100%;
				float: none;
			}

			.amp-post-title {
				font-size: 26px;
				line-height: 1.4em;
				color: <?php if ( function_exists('get_field') && get_field('text_color_10', 'elated_color') != '' ) { echo get_field('text_color_10', 'elated_color'); } else { echo '#222222'; } ?>;
				margin: 0 0 5px 0;
			}

			.sf-img {
				margin-top: 20px;
			}

			.sp {
				margin-top: 20px;
			}

			.menu-btn a {
				padding: 10px 20px;
				font-size: 14px;
			}

			.next,
			.prev {
				float: none;
				width: 100%;
			}

			#pagination {
				padding: 10px 0 0;
			}

			#respond {
				margin: 0;
			}

			.next a {
				margin-bottom: 45px;
				display: inline-block;
			}

			.prev:after {
				display: none;
			}

			.sf-img .wp-caption-text {
				width: 100%;
				padding: 10px 15px;
			}

			.fsp-img {
				width: 100%;
				float: none;
				margin-right: 0;
			}

			.fsp-cnt {
				width: 100%;
				float: none;
			}

			.fsp {
				border: none;
				padding: 0;
			}

			.fsp-cnt {}

			.r-pf .fsp-cnt {
				padding: 0;
			}
		}

		@media(max-width:425px) {

			#pagination {
				margin: 20px 0 10px 0;
			}

			.fsp h2,
			.fsp h3 {
				font-size: 24px;
				font-weight: 600;
			}
		}

		@media(max-width:320px) {
			.cntn-wrp p {
				font-size: 16px;
			}
		}

		<?php
	}
// }

?><?php if (is_single() && true==ampforwp_get_setting('ampforwp-dropcap')) {
	?>.cntn-wrp>p:first-of-type::first-letter {
		float: left;
		<?php $fontsize=ampforwp_get_setting('ampforwp-dropcap-font');

		if (empty($fontsize)) {
			?>font-size: 75px;
			<?php
		}

		else {
			?>font-size: <?php echo esc_html($fontsize) ?>px;
			<?php
		}

		?>line-height: 1;
		padding-right: 8px;
		<?php $color=ampforwp_get_setting('ampforwp-dropcap-color', 'color', 'ampforwp_sanitize_hex_color');

		if (empty($color)) {
			?>color: #000;
			<?php
		}

		else {
			?>color: <?php echo $color ?>;
			<?php
		}

		?>
	}

	<?php
}

//Drop Cap CSS ends
}

// //AMP Woocommerce condition Ends 
// Menu Search CSS
if( !ampforwp_levelup_compatibility('levelup_elementor')) {

	// Level up Condition starts
	if (isset($redux_builder_amp['menu-search']) && $redux_builder_amp['menu-search']) {
		?>.m-srch #amp-search-submit {
			cursor: pointer;
			background: transparent;
			border: none;
			display: inline-block;
			width: 30px;
			height: 30px;
			opacity: 0;
			position: absolute;
			z-index: 100;
			right: 12px;
			top: 10px;
		}

		.m-srch .amp-search-wrapper {
			border: 1px solid #ececec;
			width: 100%;
			border-radius: 60px;
		}

		.m-srch #s {
			padding: 16px 23px;
			border: none;
			width: 100%;
			border-radius: 50em;
			outline: none;
			font-size: 14px;
		}

		.m-srch {
			border-top: 1px solid #ececec;
			padding: 30px 25px;
		}

		.m-srch .overlay-search:before {
			right: 0.8em;
    		top: 0.7em;
		}

		<?php
	}

	// Menu Search CSS Ends
	if (isset($redux_builder_amp['menu-social']) && $redux_builder_amp['menu-social']) {
		?>.m-s-i {
			padding: 25px 0 15px 0;

			border-top: 1px solid <?php if(isset($redux_builder_amp['swift-element-menu-border-color']['rgba'])) {
				echo ampforwp_sanitize_color($redux_builder_amp['swift-element-menu-border-color']['rgba']);
			}

			?>;
			text-align: center;
		}

		.m-s-i li {
			font-family: 'icomoon';
			font-size: 20px;
			list-style-type: none;
			display: inline-block;
			margin: 0 15px 10px 0;
			vertical-align: middle;
		}

		.m-s-i li:last-child {
			margin-right: 0;
		}

		.m-s-i li a {
			background: transparent;
			color: <?php echo ampforwp_sanitize_color($redux_builder_amp['swift-element-overlay-color-control']['rgba'])?>;
		}

		<?php if($redux_builder_amp['enbl-fb']) {
			?>.s_fb:after {
				content: "\e92d";
			}
			<?php
		}

		if($redux_builder_amp['enbl-tw']) {
			?>.s_tw:after {
				content: "\e942";
			}
			<?php
		}

		if($redux_builder_amp['enbl-gol']) {
			?>.s_gp:after {
				content: "\e931";
			}
			<?php
		}

		if($redux_builder_amp['enbl-lk']) {
			?>.s_lk:after {
				content: "\e934";
			}
			<?php
		}

		if($redux_builder_amp['enbl-pt']) {
			?>.s_pt:after {
				content: "\e937";
			}
			<?php
		}

		if($redux_builder_amp['enbl-yt']) {
			?>.s_yt:after {
				content: "\e947";
			}
			<?php
		}

		if($redux_builder_amp['enbl-inst']) {
			?>.s_inst:after {
				content: "\e932";
			}

			<?php
		}

		if($redux_builder_amp['enbl-vk']) {
			?>.ss-ic .s_vk:after {
				content: "\e944";
			}
			<?php
		}

		if($redux_builder_amp['enbl-rd']) {
			?>.s_rd:after {
				content: "\e938";
			}
			<?php
		}

		if($redux_builder_amp['enbl-tbl']) {
			?>.s_tbl:after {
				content: "\e940";
			}
			<?php
		}

		?><?php
	}

	// Menu social CSS Ends
	if(isset($redux_builder_amp['amp-swift-menu-cprt']) && $redux_builder_amp['amp-swift-menu-cprt']) {
		?>.cp-rgt {
			font-size: 11px;
			line-height: 1.2;
			color: <?php echo ampforwp_sanitize_color($redux_builder_amp['swift-element-overlay-color-control']['rgba'])?>;
			padding: 20px;
			text-align: center;

			border-top: 1px solid <?php if(isset($redux_builder_amp['swift-element-menu-border-color']['rgba'])) {
				echo ampforwp_sanitize_color($redux_builder_amp['swift-element-menu-border-color']['rgba']);
			}

			?>;
		}

		.cp-rgt a {
			color: <?php echo ampforwp_sanitize_color($redux_builder_amp['swift-element-overlay-color-control']['rgba'])?>;
			border-bottom: 1px solid <?php echo ampforwp_sanitize_color($redux_builder_amp['swift-element-overlay-color-control']['rgba'])?>;
			margin-left: 10px;
		}

		.cp-rgt .view-non-amp {
			display: none;
		}

		a.btt:hover {
			cursor: pointer;
		}

		<?php
	}

	//Menu Copy Right CSS Ends
}

// AMP woocommerce Condition  ends ?>
<?php // Header and Archive Sidebar

if (ampforwp_get_setting('gbl-sidebar') && ampforwp_get_setting('gnrl-sidebar') && is_active_sidebar('swift-sidebar')) {

	?>.b-w,
	.arch-dsgn {
		display: flex;
	}

	.arch-psts,
	.b-w .hmp {
		display: flex;
		flex-direction: column;
		width: 70%;
		padding-right: 20px;
	}

	/*** Home page ***/
	.b-w .fsp,
	.arch-psts .fsp {
		flex-basis: calc(49.33% - 30px);
	}

	.b-w .sdbr-right {
		margin-top: 30px;
	}

	/** Custom Frontpage PB CSS **/
	.cntr.pgb {
		max-width: 1400px;
	}

	.pgb {
		margin: 0 auto;
		display: grid;
		grid-template-columns: 1fr 300px;
	}

	.pg-lft {
		display: flex;
		flex-direction: column;
		width: auto;
		padding-right: 30px;
	}

	.pgb .sdbr-right {
		width: auto;
	}

	@media(max-width:768px) {
		.pg-lft {
			width: 100%;
			padding: 0;
		}

		.pgb {
			display: inline-block;
		}
	}

	<?php
}

if ((true==ampforwp_get_setting('gbl-sidebar') && (ampforwp_is_front_page() || ampforwp_is_home() || is_archive() || is_search() || ampforwp_is_blog())) || (true==ampforwp_get_setting('swift-sidebar') || true==ampforwp_get_setting('page_sidebar') && is_singular()) || ((function_exists('is_woocommerce') && is_woocommerce()) && function_exists('ampwcpro_layout_selector') && ampwcpro_layout_selector()=='v3layout')) {
	?><?php // AMP woocommerce condition starts

	if( !ampforwp_woocommerce_conditional_check() || (function_exists('is_woocommerce') && is_woocommerce())) {
		?>

		/*** Sidebar CSS ***/
		<?php if (is_active_sidebar('swift-sidebar') || is_active_sidebar('amp-shop-sidebar') || is_active_sidebar('amp-product-sidebar')) : ?>.sdbr-right {
			<?php if(isset($redux_builder_amp['sidebar-bgcolor']['rgba']) && $redux_builder_amp['sidebar-bgcolor']['rgba']) {
				?>background: <?php echo ampforwp_sanitize_color($redux_builder_amp['sidebar-bgcolor']['rgba'])?>;
				<?php
			}

			?>display:flex;
			flex-direction:column;
			width:30%;
		}

		.amp-sidebar {
			padding: 20px;
			font-size: 14px;
			line-height: 1.5;

			<?php if(isset($redux_builder_amp['sbr-text-color']['rgba']) && $redux_builder_amp['sbr-text-color']['rgba']) {
				?>color: <?php echo ampforwp_sanitize_color($redux_builder_amp['sbr-text-color']['rgba']) ?>;
				<?php
			}

			?>
		}

		.amp-sidebar ul li {
			list-style-type: none;
			border-bottom: 1px solid <?php if ( function_exists('get_field') && get_field('text_color_01', 'elated_color') != '' ) { echo get_field('text_color_01', 'elated_color'); } else { echo '#e8e8e8'; } ?>;
			border-top: 1px solid <?php if ( function_exists('get_field') && get_field('text_color_01', 'elated_color') != '' ) { echo get_field('text_color_01', 'elated_color'); } else { echo '#e8e8e8'; } ?>;
			padding: 0.5em 0;
		}

		.amp-sidebar ul li+li {
			margin-top: -1px;
		}

		.amp-sidebar ul li ul {
			margin: 0 0 -1px;
			padding: 0;
			position: relative;
		}

		.amp-sidebar ul li li {
			border: 0;
			padding-left: 24px
		}

		.amp-sidebar ul li a:hover,
		.calendar_wrap a:hover {
			box-shadow: inset 0 0 0 rgba(0, 0, 0, 0), 0 3px 0 <?php echo ampforwp_sanitize_color($swift_cs_color) ?>;
		}

		.amp-sidebar form {
			display: inline-flex;
			flex-wrap: wrap;
			align-items: center;
		}

		.amp-sidebar .search-submit {
			text-indent: -9999px;
			padding: 0;
			margin: 0;
			background: transparent;
			line-height: 0;
			display: inline-block;
			opacity: 0;
		}

		.amp-sidebar .hide {
			display: none;
		}

		.amp-sidebar .search-field {
			border: 1px solid <?php if ( function_exists('get_field') && get_field('text_color_01', 'elated_color') != '' ) { echo get_field('text_color_01', 'elated_color'); } else { echo '#e8e8e8'; } ?>;
			padding: 6px 10px;
		}

		.sgl .calendar_wrap td {
			padding: 10px;
		}

		thead th {
			border-bottom: 1px solid <?php if ( function_exists('get_field') && get_field('text_color_01', 'elated_color') != '' ) { echo get_field('text_color_01', 'elated_color'); } else { echo '#e8e8e8'; } ?>;
			padding: 0.5em;
		}

		.amp-sidebar .gallery-item {
			display: inline-block;
			text-align: left;
			vertical-align: top;
			margin: 0 0 1.5em;
			padding: 0 1em 0 0;
			width: 50%;
		}

		.amp-sidebar .gallery-item:hover {
			opacity: 0.5;
		}

		.amp-sidebar h4 {
			<?php if(isset($redux_builder_amp['sbr-heading-color']['rgba']) && $redux_builder_amp['sbr-heading-color']['rgba']) {
				?>color: <?php echo ampforwp_sanitize_color($redux_builder_amp['sbr-heading-color']['rgba']) ?>;
				<?php
			}

			?>font-size: 12px;
			text-transform: uppercase;
			margin-bottom: 2em;
			font-weight: 800;
			letter-spacing: 0.1818em;
		}

		.amp-sidebar .tagcloud a,
		.wp_widget_tag_cloud a {
			border: 1px solid <?php if ( function_exists('get_field') && get_field('text_color_01', 'elated_color') != '' ) { echo get_field('text_color_01', 'elated_color'); } else { echo '#e8e8e8'; } ?>;
			-webkit-box-shadow: none;
			box-shadow: none;
			display: inline-block;
			margin-bottom: 5px;
			padding: 4px 10px 5px;
			position: relative;
			transition: background-color 0.2s ease-in-out, border-color 0.2s ease-in-out, color 0.3s ease-in-out;
			width: auto;
			word-wrap: break-word;
			z-index: 0;
		}

		.amp-sidebar .tagcloud a:hover,
		.wp_widget_tag_cloud a:hover {
			box-shadow: none;
			border: 1px solid <?php if ( function_exists('get_field') && get_field('text_color_08', 'elated_color') != '' ) { echo get_field('text_color_08', 'elated_color'); } else { echo '#4e4e4e'; } ?>;
		}

		.amp-sidebar .tagcloud ul li {
			float: left;
			border-top: 0;
			border-bottom: 0;
			padding: 0;
			margin: 4px 4px 0 0;
		}

		.amp-sidebar p {
			margin-bottom: 15px;
		}

		<?php endif;

		?>@media(max-width:768px) {
			.sdbr-right {
				width: 100%;
			}

			.b-w .hmp,
			.arch-psts {
				width: 100%;
				padding: 0;
			}

			.b-w,
			.arch-dsgn {
				display: block;
			}

			.b-w .fsp,
			.arch-psts .fsp {
				flex-basis: calc(100%);
			}
		}

		<?php
	}

	// AMP woocommerce condition ends
}

//Header and Archive Sidebar CSS Ends ?>
<?php if( !ampforwp_levelup_compatibility('levelup_elementor')) {

	// Level up Condition starts 
	//Footer
	if (isset($redux_builder_amp['footer-type']) && '1'==$redux_builder_amp['footer-type']) {
		?>.footer {
			margin-top: 80px;
		}

		.footer.sm-stick {
			margin-bottom: 39px;
		}

			.f-menu ul li .sub-menu {
				display: none;
			}

			.f-menu ul li {
				display: inline-block;
				margin-right: 20px;
			}

			.f-menu ul li a {
				padding: 0;
				color: <?php if ( function_exists('get_field') && get_field('text_color_08', 'elated_color') != '' ) { echo get_field('text_color_08', 'elated_color'); } else { echo '#4e4e4e'; } ?>;
			}

			.f-menu ul>li:hover a {
				color: <?php echo $hovercolor; ?>;
			}

			.f-menu {
				font-size: 14px;
				line-height: 1.4;
			}

			.f-menu ~ .rr{
				margin-top: 2.5em;
			}

			.rr {
				margin-top: 5px;
				font-size: 12px;
				color: <?php echo ampforwp_sanitize_color($redux_builder_amp['swift-footer-txt-clr']['rgba']) ?>;
			}

			.rr span {
				margin: 0 10px 0 0
			}

			.f-menu ul li.menu-item-has-children:hover>ul {
				display: none;
			}

			.f-menu ul li.menu-item-has-children:after {
				display: none;
			}
		
		<?php if (is_active_sidebar('swift-footer-widget-area')) : ?>.f-w-f1 {
			padding:<?php if(ampforwp_get_setting('ftr1-gapping')) {
				echo ' '. esc_html($redux_builder_amp['ftr1-gapping']['padding-top']);
				echo ' '. esc_html($redux_builder_amp['ftr1-gapping']['padding-right']);
				echo ' '. esc_html($redux_builder_amp['ftr1-gapping']['padding-bottom']);
				echo ' '. esc_html($redux_builder_amp['ftr1-gapping']['padding-left']);
			}

			?>;
			width:100%;
			border-top: 1px solid <?php echo ampforwp_sanitize_color($redux_builder_amp['swift-footer-brdrclr']['rgba'])?>;
		}

		<?php endif;

		?>.f-w {
			display: inline-flex;
			width: 100%;
			flex-wrap: wrap;
			margin: 15px -15px 0;
		}

		.f-w-f2 {
			text-align: center;
			padding: 2.5em 0;
		}

		.w-bl {
			margin-left: 0;
			display: flex;
			flex-direction: column;
			position: relative;
			flex: 1 0 22%;
			margin: 0 15px 30px;
			line-height: 1.5;
			font-size: 14px;
		}

		.w-bl h4 {
			font-size: <?php echo esc_html(ampforwp_get_setting('swift-head-size'));
			?>;
			font-weight: <?php echo esc_html(ampforwp_get_setting('swift-head-fntwgth')) ?>;
			margin-bottom: 20px;
			text-transform: uppercase;
			letter-spacing: 1px;
			padding-bottom: 4px;
		}

		.w-bl ul li {
			list-style-type: none;
			margin-bottom: 15px;
		}

		.w-bl ul li:last-child {
			margin-bottom: 0;
		}

		.w-bl ul li a {
			text-decoration: none;
		}

		.w-bl .menu li .sub-menu,
		.w-bl .lb-x {
			display: none;
		}

		.w-bl .menu li .sub-menu,
		.w-bl .lb-x {
			display: none;
		}

		.w-bl table {
			border-collapse: collapse;
			margin: 0 0 1.5em;
			width: 100%;
		}

		.w-bl tr {
			border-bottom: 1px solid <?php if ( function_exists('get_field') && get_field('text_color_01', 'elated_color') != '' ) { echo get_field('text_color_01', 'elated_color'); } else { echo '#e8e8e8'; } ?>;
		}

		.w-bl th,
		.w-bl td {
			text-align: center;
		}

		.w-bl td {
			padding: 0.4em;
		}

		.w-bl th:first-child,
		.w-bl td:first-child {
			padding-left: 0;
		}

		.w-bl thead th {
			border-bottom: 1px solid <?php if ( function_exists('get_field') && get_field('text_color_01', 'elated_color') != '' ) { echo get_field('text_color_01', 'elated_color'); } else { echo '#e8e8e8'; } ?>;
			padding-bottom: 0.5em;
			padding: 0.4em;
		}

		.w-bl .calendar_wrap caption {
			font-size: 14px;
			margin-bottom: 10px;
		}

		.w-bl form {
			display: inline-flex;
			flex-wrap: wrap;
			align-items: center;
		}

		.w-bl .search-submit {
			text-indent: -9999px;
			padding: 0;
			margin: 0;
			background: transparent;
			line-height: 0;
			display: inline-block;
			opacity: 0;
		}

		.w-bl .search-button:after {
			content: "\e8b6";
			font-family: 'icomoon';
			font-size: 23px;
			display: inline-block;
			cursor: pointer;
		}

		.w-bl .search-field {
			border: 1px solid <?php if ( function_exists('get_field') && get_field('text_color_01', 'elated_color') != '' ) { echo get_field('text_color_01', 'elated_color'); } else { echo '#e8e8e8'; } ?>;
			padding: 6px 10px;
		}

		<?php

		/*** New footer Features ***/
		if(isset($redux_builder_amp['footer-customize-options']) && true==$redux_builder_amp['footer-customize-options']) {
			?>.f-w {
				flex-wrap: wrap;
			}

			.f-w-f2 {
				line-height: 1.5;
				background: <?php if ( function_exists('get_field') && get_field('footer_bg_color', 'elated_color') != '' ) { echo get_field('footer_bg_color', 'elated_color'); } else { echo '#f8f8f8'; } ?>;
				font-size: <?php echo esc_html(ampforwp_get_setting('swift-footer1-cntnsize'))?>;
				color: <?php if ( function_exists('get_field') && get_field('footer_text_color', 'elated_color') != '' ) { echo get_field('footer_text_color', 'elated_color'); } else { echo '#222222'; } ?>;
				display: inline-block;
				clear: both;
				width: 100%;
			}

			.w-bl h4 {
				color: <?php if ( function_exists('get_field') && get_field('footer_text_color', 'elated_color') != '' ) { echo get_field('footer_text_color', 'elated_color'); } else { echo '#222222'; } ?>;
			}

			.w-bl a,
			.f-menu ul li a,
			.rr a {
				color: <?php if ( function_exists('get_field') && get_field('footer_text_color', 'elated_color') != '' ) { echo get_field('footer_text_color', 'elated_color'); } else { echo '#222222'; } ?>;
			}

			.w-bl a:hover,
			.f-menu ul li a:hover,
			.rr a:hover {
				color: <?php if ( function_exists('get_field') && get_field('accent_color', 'elated_color') != '' ) { echo get_field('accent_color', 'elated_color'); } else { echo '#c39867'; } ?>;
			}

			.w-bl p {
				margin-bottom: 15px;
			}
			<?php
		}

		// New footer feature closed
		else {

			// Default Footer CSS ?>
			.f-menu {
				font-size: 14px;
				line-height: 1.4;
				margin-bottom: 30px;
			}

			.f-menu ul li {
				display: inline-block;
				margin-right: 20px;
			}

			.f-menu .sub-menu {
				display: none;
			}

			.rr {
				font-size: 13px;
				color: <?php echo ampforwp_sanitize_color($redux_builder_amp['swift-footer-txt-clr']['rgba']) ?>;
			}

			<?php
		}

		// If advanced footer is disabled Default Footer CSS will be load ?>
		@media(max-width:768px) {
			.footer {
				margin-top: 60px;
			}

			.w-bl {
				flex: 1 0 22%;
			}
		}

		@media(max-width:480px) {
			.footer {
				margin-top: 50px;
			}

			<?php if (is_active_sidebar('swift-footer-widget-area')) : ?>.f-w-f1 {
				padding: 45px 0 10px 0;
			}
			<?php endif; ?>

			.f-w {
				display: block;
				margin: 15px 0 0;
			}

			.w-bl {
				margin-bottom: 40px;
			}

			.w-bl {
				flex: 100%;
			}

			.w-bl ul li {
				margin-bottom: 11px;
			}

			.f-menu ul li {
				display: inline-block;
				line-height: 1.8;
				margin-right: 13px;
			}

			.f-menu .amp-menu>li a {
				padding: 0;
				font-size: 12px;
				color: #7a7a7a;
			}

			.rr {
				font-size: 11px;

				<?php if($redux_builder_amp['amp-gdpr-compliance-switch']=='1') {
					?>line-height: 1.8;
					<?php
				}

				?>
			}
		}

		@media(max-width:425px) {
			.footer {
				margin-top: 35px;
			}

			<?php if (is_active_sidebar('swift-footer-widget-area')) : ?>.f-w-f1 {
				padding: 35px 0 10px 0;
			}

			<?php endif;

			?>.w-bl h4 {
				margin-bottom: 15px;
			}
		}

		<?php if(checkAMPforPageBuilderStatus(get_the_ID()) && (ampforwp_is_front_page() || is_page())) {
			?>.footer {
				margin-top: 0;
			}

			<?php
		}

		?><?php if(ampforwp_is_home() || ampforwp_is_blog()) {
			?>.footer {
				margin-top: 20px;
			}

			<?php
		}

		?><?php
	}

	?><?php //Sticky Social Icons

	if(is_single() || is_page()) {
		?>.ss-ic ul li {
			font-family: 'icomoon';
			list-style-type: none;
			display: inline-block;
		}

		.ss-ic li a {
			color: #fff;
			padding: 5px;
			border-radius: 3px;
			margin: 0 10px 10px 0;
			display: inline-block;
		}

		<?php if($redux_builder_amp['enable-single-facebook-share'] || $redux_builder_amp['enbl-fb']) {
			?>.ss-ic ul li .s_fb {
				color: #fff;
				background: #3b5998;
			}

			.s_fb:after {
				content: "\e92d";
			}

			<?php
		}

		if(ampforwp_get_setting('enable-single-facebook-share-messenger')) {
			?>.s_fb_ms {
				color: #fff;
				background: #3b5998;
			}

			.s_fb_ms:after {
				content: "\e935";
			}

			<?php
		}

		if($redux_builder_amp['enable-single-twitter-share'] || $redux_builder_amp['enbl-tw']) {
			?><?php if(function_exists('mvp_setup')) {
				?>.zox_tw:after {
					content: "\e942";
					color: #1da1f2;
				}

				<?php
			}

			?>.s_tw {
				background: #1da1f2;
			}

			.s_tw:after {
				content: "\e942";
			}

			<?php
		}

		if($redux_builder_amp['enable-single-linkedin-share'] || $redux_builder_amp['enbl-lk']) {
			?>.s_lk {
				background: #0077b5;
			}

			.s_lk:after {
				content: "\e934";
			}

			<?php
		}

		if($redux_builder_amp['enable-single-pinterest-share'] || isset($redux_builder_amp['enbl-pt']) && $redux_builder_amp['enbl-pt']) {
			?>.s_pt {
				background: #bd081c;
			}

			.s_pt:after {
				content: "\e937";
			}

			<?php
		}

		if($redux_builder_amp['enable-single-email-share']) {
			?>.s_em {
				background: #b7b7b7;
			}

			.s_em:after {
				content: "\e930";
			}

			<?php
		}

		if($redux_builder_amp['enable-single-whatsapp-share']) {
			?>.s_wp {
				background: #075e54;
			}

			.s_wp:after {
				content: "\e946";
			}

			<?php
		}

		if($redux_builder_amp['enable-single-odnoklassniki-share']) {
			?>.s_od {
				background: #ed812b;
			}

			.s_od:after {
				content: "\e936";
			}

			<?php
		}

		if($redux_builder_amp['enable-single-vk-share']) {
			?>.s_vk {
				background: #45668e;
			}

			.s_vk:after {
				content: "\e944";
			}

			<?php
		}

		if(ampforwp_get_setting('enable-single-line-share')==true) {
			?>.s_li {
				background: #00cc00;
			}

			<?php
		}

		if(ampforwp_get_setting('enable-single-mewe-share')==true) {
			?>.s_mewe {
				background: #b8d6e6;
			}

			<?php
		}

		if(ampforwp_get_setting('enable-single-flipboard-share')==true) {
			?>.s_flipboard {
				background: #f52828;
			}

			<?php
		}

		if($redux_builder_amp['enable-single-reddit-share']) {
			?>.s_rd {
				background: #ff4500;
			}

			.s_rd:after {
				content: "\e938";
			}

			<?php
		}

		if($redux_builder_amp['enable-single-tumblr-share']) {
			?>.s_tb {
				background: #35465c;
			}

			.s_tb:after {
				content: "\e940";
			}

			<?php
		}

		if($redux_builder_amp['enable-single-telegram-share']) {
			?>.s_tg {
				background: #0088cc;
			}

			.s_tg:after {
				content: "\e93f";
			}

			<?php
		}

		if($redux_builder_amp['enable-single-stumbleupon-share']) {
			?>.s_su {
				background: #eb4924;
			}

			.s_su:after {
				content: "\e93e";
			}

			<?php
		}

		if($redux_builder_amp['enable-single-wechat-share']) {
			?>.s_wc {
				background: #7bb32e;
			}

			.s_wc:after {
				content: "\e945";
			}

			<?php
		}

		if($redux_builder_amp['enable-single-viber-share']) {
			?>.s_vb {
				background: #59267c;
			}

			.s_vb:after {
				content: "\e943";
			}

			<?php
		}

		if(isset($redux_builder_amp['enable-single-yummly-share']) && $redux_builder_amp['enable-single-yummly-share']) {
			?>.s_ym {
				background: #e26426
			}

			.s_ym:after {
				content: "\e948";
			}

			<?php
		}

		if(isset($redux_builder_amp['enable-single-hatena-bookmarks']) && $redux_builder_amp['enable-single-hatena-bookmarks']) {
			?>.s_hb {
				background: #00a4de
			}

			.s_hb:after {
				content: "\e948";
			}

			<?php
		}

		if(isset($redux_builder_amp['enable-single-pocket-share']) && $redux_builder_amp['enable-single-pocket-share']) {
			?>.s_pk {
				background: #ef3f56
			}

			.s_pk:after {
				content: "\e949";
			}

			<?php
		}

		?><?php if (true==ampforwp_get_setting('enable-single-flipboard-share')) {
			?>.s_fd {
				background: #f52828
			}

			<?php
		}

		?><?php if(ampforwp_get_setting('enable-single-social-icons')) {
			?>.s_stk {
				background: #f1f1f1;
				display: inline-block;
				width: 100%;
				padding: 0;
				position: fixed;
				bottom: 0;
				text-align: center;
				border: 0;
			}

			.s_stk ul {
				width: 100%;
				display: inline-flex;
			}

			.s_stk ul li {
				flex-direction: column;
				flex-basis: 0;
				flex: 1 0 5%;
				max-width: calc(100% - 10px);
				display: flex;
				height: 40px
			}

			.s_stk li a {
				margin: 0;
				border-radius: 0;
				padding: 12px;
			}

			<?php
		}

		//Sticky CSS Condition ends
	}

	?><?php
}

// levelup condition ends ?>
<?php if(ampforwp_get_setting('enable-single-social-icons') && is_single()) {
	?>

	.s_stk {
		z-index: 99;
	}

	.body.single-post .adsforwp-stick-ad,
	.body.single-post amp-sticky-ad {
		padding-bottom: 45px;
		padding-top: 5px;
	}

	.body.single-post .ampforwp-sticky-custom-ad {
		bottom: 40px;
		padding: 3px 0 0;
	}

	.body.single-post .afw a {
		line-height: 0;
	}

	.body.single-post amp-sticky-ad amp-sticky-ad-top-padding {
		height: 0;
	}

	<?php
}

//Sticky CSS Condition ends?>
<?php if(ampforwp_get_setting('ampforwp-advertisement-sticky-type')==3) {
	?>.btt {
		z-index: 9999;
	}

	<?php
}

// advanced ads type 3 ends here ?>
<?php if( !ampforwp_levelup_compatibility('levelup_elementor')) {

	// Level up Condition starts ?>
	.content-wrapper a,
	.breadcrumb ul li a,
	.srp ul li,
	.rr a {
		transition: all 0.3s ease-in-out 0s;
	}

	[class^="icon-"],
	[class*=" icon-"] {
		font-family: 'icomoon';
		speak: none;
		font-style: normal;
		font-weight: normal;
		font-variant: normal;
		text-transform: none;
		line-height: 1;
		-webkit-font-smoothing: antialiased;
		-moz-osx-font-smoothing: grayscale;
	}

	<?php if(true==ampforwp_get_setting('enable-amp-ads-1')||true==ampforwp_get_setting('enable-amp-ads-2')||true==ampforwp_get_setting('enable-amp-ads-3')||true==ampforwp_get_setting('enable-amp-ads-4')||true==ampforwp_get_setting('enable-amp-ads-5')||true==ampforwp_get_setting('enable-amp-ads-6')) {
		?>body .amp-ad-wrapper {
			width: 100%;
			text-align: center;
			margin: 10px 0;
		}

		.amp-ad-wrapper span {
			display: inherit;
			font-size: 12px;
			line-height: 1;
		}

		<?php
	}

	?><?php if(isset($redux_builder_amp['enable-amp-ads-1']) && $redux_builder_amp['enable-amp-ads-1']) {
		?>.amp_ad_1 {
			margin: -2px 0 -17px 0;
		}

		<?php
	}

	if(isset($redux_builder_amp['enable-amp-ads-2']) && $redux_builder_amp['enable-amp-ads-2']) {
		?>.amp_ad_2 {
			margin: 20px 0 -23px 0;
		}

		<?php
	}

	if(isset($redux_builder_amp['enable-amp-ads-3']) && $redux_builder_amp['enable-amp-ads-3']) {
		?>.amp-ad-3 {
			margin: 0 0 -4px 0;
		}

		<?php
	}

	if(isset($redux_builder_amp['enable-amp-ads-4']) && $redux_builder_amp['enable-amp-ads-4']) {
		?>.amp_ad_4 {
			margin: 20px 0 20px 0;
		}

		<?php
	}

	if(isset($redux_builder_amp['enable-amp-ads-5']) && $redux_builder_amp['enable-amp-ads-5']) {
		?>.amp_ad_5 {
			margin: 10px 0 -17px 0;
		}

		<?php
	}

	if(isset($redux_builder_amp['enable-amp-ads-6']) && $redux_builder_amp['enable-amp-ads-6']) {
		?>.amp-ad-6 {
			margin: 0 0 20px 0;
		}

		<?php
	}

	?><?php if(true==$redux_builder_amp['amp-enable-notifications']) {
		?>#amp-user-notification1 {
			padding: 5px;
			text-align: center;
			background: <?php if ( function_exists('get_field') && get_field('white_color', 'elated_color') != '' ) { echo get_field('white_color', 'elated_color'); } else { echo '#ffffff'; } ?>;
			border-top: 1px solid <?php if ( function_exists('get_field') && get_field('text_color_01', 'elated_color') != '' ) { echo get_field('text_color_01', 'elated_color'); } else { echo '#e8e8e8'; } ?>;
		}

		#amp-user-notification1 p {
			display: inline-block;
			margin: 20px 0;
		}

		amp-user-notification button {
			padding: 8px 10px;
			background: <?php if ( function_exists('get_field') && get_field('text_color_10', 'elated_color') != '' ) { echo get_field('text_color_10', 'elated_color'); } else { echo '#222222'; } ?>;
			color: <?php if ( function_exists('get_field') && get_field('white_color', 'elated_color') != '' ) { echo get_field('white_color', 'elated_color'); } else { echo '#ffffff'; } ?>;
			margin-left: 5px;
			border: 0;
		}

		amp-user-notification .amp-not-privacy {
			color: <?php if ( function_exists('get_field') && get_field('text_color_10', 'elated_color') != '' ) { echo get_field('text_color_10', 'elated_color'); } else { echo '#222222'; } ?>;
			font-size: 15px;
			margin-left: 5px;
		}

		<?php
	}

	// Notice bar CSS Ends?>
	<?php
}

// Levelup Condition ends?>
<?php //RTL Styles 

if(true==$redux_builder_amp['amp-rtl-select-option']) {
	?>.body {
		direction: rtl;
	}

	.h-1 {
		order: -1;
	}

	.h-nav {
		order: 1;
	}

	.h-2 {
		order: -2;
	}

	.h-3 {
		order: -2;
		justify-content: flex-start;
	}

	.h-3 .h-srch {
		margin-left: 0;
	}

	.h-3 .h-nav {
		order: -1;
		margin: 0 10px 0 0;
	}

	.right a,
	.left a {
		direction: rtl;
	}

	.w-bl {
		direction: rtl;
	}

	.loop-wrapper {
		direction: rtl;
	}

	.breadcrumb,
	.amp-category {
		direction: rtl;
	}

	.item-home:after {
		padding-right: 5px;
	}

	.amp-post-title {
		text-align: right;
	}

	.post-date .post-edit-link {
		float: left;
	}

	.sp-rt {
		direction: rtl;
		margin-right: 50px;
		margin-left: 0;
	}

	.sp-rt .amp-author .amp-author-image {
		float: right;
	}

	.amp-author-image amp-img {
		margin: 0 0 5px 12px;
	}

	.prev {
		float: right;
	}

	.next {
		float: left;
	}

	.r-pf {
		direction: rtl;
	}

	.prev:after {
		left: -25px;
		right: auto;
	}

	.f-menu,
	.p-menu {
		direction: rtl;
	}

	.sp-lt {
		direction: rtl;
	}

	.comment-meta amp-img {
		float: right;
		margin-left: 10px;
	}

	.archive .author-img {
		float: right;
	}

	.archive .author-img amp-img {
		margin: 0 0 10px 12px;
	}

	.amp-archive-title,
	.amp-archive-desc {
		text-align: right;
	}

	@media(max-width:768px) {
		.fsp-img {
			float: right;
			margin-right: 0;
			margin-left: 20px;
		}

		.rlp-image {
			float: right;
			margin-left: 15px;
			margin-right: 0;
		}

		.sp-rt {
			margin-right: 0
		}
	}

	@media(max-width:480px) {
		.next a {
			text-align: left;
		}

		.next span {
			right: auto;
			left: 0;
		}

		.post-date .post-edit-link {
			float: left;
		}

		.fsp-cnt {
			width: 100%;
			float: none;
			display: inline-block;
		}
	}

	<?php
}

// Menu RTL Styles 
if(true==$redux_builder_amp['amp-rtl-select-option']) {
	?>.h-nav {
		order: -1;
	}

	.h-1 {
		order: 0;
	}

	.c-btn {
		float: left;
	}

	.overlay-search:before {
		left: 0;
		right: auto;
	}

	a.lb-x {
		left: 0;
		right: auto;
	}

	<?php if($redux_builder_amp['header-position-type']=='1') {
		?>.tg:checked+.hamb-mnu>.m-ctr {
			margin-right: 0%;
		}

		.m-ctr {
			margin-right: -100%;
			float: left;
		}

		<?php
	}

	?><?php if($redux_builder_amp['header-position-type']=='2') {
		?>.tg:checked+.hamb-mnu>.m-ctr {
			margin-right: calc(100% - <?php echo esc_html(ampforwp_get_setting('header-overlay-width'))?>);
		}

		.m-ctr {
			margin-right: 100%;
			float: right;
		}

		<?php
	}

	?>.m-menu li.menu-item-has-children:hover:after {
		right: auto;
		left: 0;
	}

	.m-menu ul li.menu-item-has-children:after {
		right: auto;
		left: 0;
	}

	.amp-ad-wrapper {
		direction: ltr;
	}

	<?php
}

//RTL End ?>
<?php if( !ampforwp_levelup_compatibility('levelup_elementor')) {

	// Level up Condition starts 
	if (ampforwp_get_setting('enable-amp-ads-resp-1')) {
		?>.amp-ad-1 {
			max-width: 1000px;
		}

		<?php
	}

	?><?php if (ampforwp_get_setting('enable-amp-ads-resp-2')) {
		?>.amp-ad-2 {
			max-width: 1000px;
		}

		<?php
	}

	?><?php if (ampforwp_get_setting('enable-amp-ads-resp-3')) {
		?>.amp-ad-3 {
			max-width: 1000px;
		}

		<?php
	}

	?><?php if (ampforwp_get_setting('enable-amp-ads-resp-4')) {
		?>.amp-ad-4 {
			max-width: 1000px;
		}

		<?php
	}

	?><?php if (ampforwp_get_setting('enable-amp-ads-resp-5')) {
		?>.amp-ad-5 {
			max-width: 1000px;
		}

		<?php
	}

	?><?php if (ampforwp_get_setting('enable-amp-ads-resp-6')) {
		?>.amp-ad-6 {
			max-width: 1000px;
		}

		<?php
	}

	?><?php
}

// levelup condition ends here?>
<?php if (checkAMPforPageBuilderStatus(get_the_ID())) {
	?>.sp-cnt .cntr {
		max-width: 100%;
		margin: 0;
		width: 100%;
		padding: 0
	}

	.amp_mod.text-mod p {
		margin: 0 0 1.5em;
	}

	<?php
}

?>



<?php if(true==ampforwp_get_setting('ampforwp-smooth-scrolling-for-links')) {
	?>html {
		scroll-behavior: smooth;
	}

	<?php
}

// Infinate Scroll Home & Archive page CSS
if(true==ampforwp_get_setting('ampforwp-infinite-scroll') && ampforwp_get_setting('ampforwp-infinite-scroll-home')) {
	?>

	/** Home & Archive CSS **/
	.body amp-next-page {
		margin: 0 -30px 0 -30px
	}

	.amp-next-page-default-separator {
		padding-top: 30px;
		border: none;
	}

	@media(max-width:1024px) {
		.body amp-next-page {
			margin: 0 -20px 0 -20px;
		}

		.amp-next-page-default-separator {
			padding-top: 10px;
		}
	}

	@media(max-width:480px) {
		.body amp-next-page {
			margin: 0;
		}

		.loop-wrapper {
			margin: 0;
			display: inline-block;
		}
	}

	<?php
}

// Infinate Scroll Single page CSS
if(true==ampforwp_get_setting('ampforwp-infinite-scroll') && ampforwp_get_setting('ampforwp-infinite-scroll-single')) {
	?>.r-pf .fsp {
		margin: 15px;
	}

	@media(max-width:1024px) {
		.body amp-next-page {
			margin: 0 0 0 0;
		}
	}

	<?php
}

// image floats removed in mobile view #2525
if(function_exists('if_is_levelup') && !if_is_levelup() && !if_levelup_has_builder()) {

	// Level up Condition starts 
	if(is_singular() || ampforwp_is_front_page()) {
		?>@media(max-width:480px) {

			.content-wrapper .alignright,
			.content-wrapper .alignleft {
				float: none;
				margin: 0 auto;
			}
		}

		<?php
	}

	?><?php
}

// levelup condition ends here?> 
@media (min-width: 768px) {
	.wp-block-columns {
		display: flex;
	}

	.wp-block-column {
		max-width: 50%;
		margin: 0 10px;
	}
}

<?php // Notification CSS
if(ampforwp_get_setting('amp-enable-notifications') && ampforwp_get_setting('enable-single-social-icons') && is_single()) {
	?>amp-user-notification {
		bottom: 40px;
	}

	<?php
}

//amp-enable-notifications Condition Ends Here ?> 
amp-facebook-like {
	max-height: 28px;
	top: 6px;
	margin-right: -5px;
}

<?php 

if(true==ampforwp_get_setting('ampforwp-single-related-posts-excerpt')) {
	?>a.readmore-rp {
		font-size: 13px;
	}

	<?php
}

if(is_page()) {
	?>.ss-ic li a {
		display: initial;
	}
	<?php
}

if(ampforwp_get_setting('ampforwp-gallery-design-type')==3) {
	?>.ampforwp-gallery-item.amp-carousel-containerd3 {
		float: left;
	}

	.amp-carousel-containerd3 figcaption {
		max-width: 150px;
	}

	<?php
}

?>.m-s-i li a.s_telegram {
	background: #d0d0d0;
	padding: 0 2px;
	border-radius: 2px;
}

.cntn-wrp h1,
.cntn-wrp h2,
.cntn-wrp h3,
.cntn-wrp h4,
.cntn-wrp h5,
h6 {
	margin-bottom: 18px;
    line-height: 1.7em;
}

<?php // H1 - H6 Font Sizes 

if(ampforwp_get_setting('swift_cnt') && ampforwp_get_setting('swift_cnt_h1')) {
	?>.cntn-wrp h1 {
		font-size: <?php echo esc_html(ampforwp_get_setting('swift_h1_sz'))?>;
	}

	<?php
}

else {
	?>.cntn-wrp h1 {
		font-size: 30px;
	}

	<?php
}

//H1 ends
if(ampforwp_get_setting('swift_cnt') && ampforwp_get_setting('swift_cnt_h2')) {
	?>.cntn-wrp h2 {
		font-size: <?php echo esc_html($redux_builder_amp['swift_h2_sz'])?>;
	}

	<?php
}

else {
	?>.cntn-wrp h2 {
		font-size: 27px;
	}

	<?php
}

// H2 Ends
if(ampforwp_get_setting('swift_cnt') && ampforwp_get_setting('swift_cnt_h3')) {
	?>.cntn-wrp h3 {
		font-size: <?php echo esc_html(ampforwp_get_setting('swift_h3_sz'))?>;
	}

	<?php
}

else {
	?>.cntn-wrp h3 {
		font-size: 24px;
	}

	<?php
}

// H3 Ends
if(ampforwp_get_setting('swift_cnt') && ampforwp_get_setting('swift_cnt_h4')) {
	?>.cntn-wrp h4 {
		font-size: <?php echo esc_html(ampforwp_get_setting('swift_h4_sz'))?>;
	}

	<?php
}

else {
	?>.cntn-wrp h4 {
		font-size: 20px;
	}

	<?php
}

// H4 Ends
if(ampforwp_get_setting('swift_cnt') && ampforwp_get_setting('swift_cnt_h5')) {
	?>.cntn-wrp h5 {
		font-size: <?php echo esc_html(ampforwp_get_setting('swift_h5_sz'))?>;
	}

	<?php
}

else {
	?>.cntn-wrp h5 {
		font-size: 17px;
	}

	<?php
}

// H5 Ends
if(ampforwp_get_setting('swift_cnt') && ampforwp_get_setting('swift_cnt_h6')) {
	?>.cntn-wrp h6 {
		font-size: <?php echo esc_html(ampforwp_get_setting('swift_h6_sz'))?>;
	}

	<?php
}

else {
	?>.cntn-wrp h6 {
		font-size: 15px;
	}

	<?php
}

// H6 Ends

// Hide Featured Tag
if(function_exists('get_field') && get_field('hide_featured_category', 'elated_featured_slider')==true) {
	$excluded_cat=get_field('filter_by_category', 'elated_featured_slider');
	echo '.loop-meta .amp-cat-'.$excluded_cat.'{ display:none; }';
	echo '.loop-meta .amp-cat-'.$excluded_cat.' ~ li:before{ display:none; }';
}
?>
@media(min-width:769px) {
	.loop-wrapper {
		margin-left: -15px;
		margin-right: -15px;
		padding: 15px 20px 0;
	}

	.fsp {
		padding: 0;
		margin: 5px 15px 35px;
	}
}